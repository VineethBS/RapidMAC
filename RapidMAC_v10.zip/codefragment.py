Start Node ----> Random Backoff Node
Wait for Packet Node ----> Random Backoff Node
