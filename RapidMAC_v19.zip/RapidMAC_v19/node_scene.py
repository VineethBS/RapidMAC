from node_graphics_scene import QDMGraphicsScene

class Scene():
    def __init__(self):
        print('*----node_scene----*')
        self.nodes = []
        self.edges = []

        self.scene_width = 64000
        self.scene_height = 64000

        self.initUI()

    def initUI(self):
        self.grScene = QDMGraphicsScene(self)
        self.grScene.setGrScene(self.scene_width, self.scene_height)

    def addNode(self, node):
        print('....node_scene.py - addNode')
        self.nodes.append(node)

    def addEdge(self, edge):
        print('....node_scene.py - addEdge')
        self.edges.append(edge)

    def removeNode(self, node):
        print('....node_scene.py - removeNode')
        self.nodes.remove(node)

    def removeEdge(self,edge):
        print('....node_scene.py - removeEdge')
        self.edges.remove(edge)

        


