Wait for Packet Node ----> Send Packet Node
Random Backoff Node ----> Send Packet Node
Start Node ----> Wait for Packet Node
