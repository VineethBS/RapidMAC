import os
import sys
import pickle
from PyQt5 import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from node_editor_wnd import NodeEditorWnd

listItems = ["Wait for Packet","Random Backoff","Send Packet"]

class MainWin(QMainWindow):
    def __init__(self):
        super(MainWin,self).__init__()

        toolbar = self.addToolBar('Toolbar')
##        self.inUI()
##        self.panelUI()

        splitter1 = QSplitter(Qt.Horizontal)
##
##        topleft = QWidget()      # QFrame has no attribute 'toolbar'
####        topleft.setFrameShape(QFrame.StyledPanel)
        btn1 = QPushButton('Nodes', self)
        btn2 = QPushButton('Edges', self)
        btn3 = QPushButton('Select', self)
        toolbar.addWidget(btn1)
        toolbar.addWidget(btn2)
        toolbar.addWidget(btn3)
##        

        left = NodeEditorWnd()
        myListWidget = QListWidget()
        myListWidget.setAlternatingRowColors(True)
        myListWidget.setDragDropMode(QAbstractItemView.InternalMove)
        for i in range (3):
            myListWidget.addItem(listItems[i])

        splitter1.addWidget(left)
        splitter1.addWidget(myListWidget)
        splitter1.setSizes([300,50])
        
        self.statusBar().showMessage('Ready')
####        screen = QtGui.QDesktopWidget().screenGeometry()
####        self.setGeometry(0, 0, screen.width(), screen.height())
        self.showMaximized()

##        self.setGeometry(200,200,480,320)
        self.setCentralWidget(splitter1)
##        self.setGeometry(500, 300, 700, 300)
        self.setWindowTitle('Rapid MAC')
        self.show()
	
def main():
    app = QApplication(sys.argv)
    ex = MainWin()
    sys.exit(app.exec_())
	
if __name__ == '__main__':
    main()

