from node_graphics_edge import *
##from nodeEditor_main import savebuttonClicked
import networkx as nx

EDGE_TYPE_DIRECT = 1
EDGE_TYPE_BEZIER = 2

DEBUG = False

codefragment = []
edge_startnode = []
edge_endnode = []

NODE_1 = 0


class Edge:
    def __init__(self,scene,net,start_socket,end_socket, edge_type=EDGE_TYPE_DIRECT):
        self.scene = scene

        self.net = net
        
        self.start_socket = start_socket
        self.end_socket = end_socket

        self.start_socket.edge = self
        if self.end_socket is not None:
            self.end_socket.edge = self

        self.grEdge = QDMGraphicsEdgeDirect(self) if edge_type==EDGE_TYPE_DIRECT else QDMGraphicsEdgeBezier(self)

        self.updatePositions()

##        print("Edge:", self.grEdge.posSource, "to", self.grEdge.posDestination)
         
        self.scene.grScene.addItem(self.grEdge)
        self.scene.addEdge(self)

    def __str__(self):
        return "<Edge %s..%s>" % (hex(id(self))[2:5], hex(id(self))[-3:])

    def updatePositions(self):
        if self.start_socket is not None:
            source_pos = self.start_socket.getSocketPosition()
            source_pos[0] += self.start_socket.node.grNode.pos().x()
            source_pos[1] += self.start_socket.node.grNode.pos().y()
            
        self.grEdge.setSource(*source_pos)
        
        if self.end_socket is not None:
            end_pos = self.end_socket.getSocketPosition()
            end_pos[0] += self.end_socket.node.grNode.pos().x()
            end_pos[1] += self.end_socket.node.grNode.pos().y()
            self.edge_startnode = hex(id(self.start_socket.node.grNode))  #------->sbt
            self.edge_endnode = hex(id(self.end_socket.node.grNode))  #------->sbt
            print('start node: ',self.edge_startnode)
            print('start node.grNode: ',self.start_socket.node.grNode)
            print('end node: ',self.edge_endnode)
            print('end node.grNode: ',self.end_socket.node.grNode)
            codefragment.append((self.edge_startnode,self.edge_endnode))

            self.net.add_edge(hex(id(self.start_socket.node.grNode)),hex(id(self.end_socket.node.grNode)))
##            nx.draw(self.net,with_labels = True)
            
            print('codefragment:(before) = ',codefragment)
            L = len(codefragment)
            print('Length of codefragment:',L)
            if L > 1:
                for a in range (0,L-1):
                    print('inside if L>1:::', len(codefragment))
                    print('codefragment[a] = ', codefragment[a])
                    print('start_node = ',codefragment[a][0], 'end_node = ',codefragment[a][1])
                    if ((codefragment[a][0] == self.edge_startnode) and (codefragment[a][1] == self.edge_endnode)):
                        del codefragment[-1]
                        
                        self.net.remove_edge(hex(id(self.start_socket.node.grNode)),hex(id(self.end_socket.node.grNode)))
##                        nx.draw(self.net,with_labels = True)
                        
                        print('edge already present')
##                        pass
            self.grEdge.setDestination(*end_pos)
##            self.grEdge.setDestination(*source_pos)
        else:
            self.grEdge.setDestination(*source_pos)
##        print("SS:", self.start_socket)
##        print("ES:", self.end_socket)
        self.grEdge.update()
##        self.net.add_edges_from(codefragment)
##        nx.draw(self.net,with_labels = True)
        return self.net
        print('codefragment = ',codefragment)

    def remove_from_sockets(self):
        print("----remove_from_sockets----")
        if self.start_socket is not None:
            self.start_socket.edge = None
        if self.end_socket is not None:
            self.end_socket.edge = None
        self.end_socket = None
        self.start_socket = None
        codefragment.remove((self.edge_startnode,self.edge_endnode))
##        del codefragment[-1]    
        self.net.remove_edge(hex(id(self.start_socket.node.grNode)),hex(id(self.end_socket.node.grNode)))
##        nx.draw(self.net,with_labels = True)

    def remove(self):
        print("-----remove_------")
        self.remove_from_sockets()
        self.scene.grScene.removeItem(self.grEdge)
        self.grEdge = None
        self.scene.removeEdge(self)
        self.updatePositions()
##        return self.net


