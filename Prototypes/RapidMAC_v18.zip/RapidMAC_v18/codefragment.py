Wait for Packet Node ----> Send Packet Node
Random Backoff Node ----> Send Packet Node
Wait for Packet Node ----> Random Backoff Node
Start Node ----> Wait for Packet Node
