Start Node ---> Wait for Packet Node
Wait for Packet Node ---> Random Backoff Node
Random Backoff Node ---> Send Packet Node
