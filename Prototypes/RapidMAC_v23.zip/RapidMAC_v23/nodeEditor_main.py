# ! /usr/bin/env python 3.6.7
# -*- coding utf-8 -*-

import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5 import QtWidgets
from node_editor_wnd import NodeEditorWnd
from node_node import Node, codefragmenttext, St_node, Wp_node, Rb_node, Sp_node
from node_edge import Edge, codefragment
import networkx as nx
import matplotlib.pyplot as plt

mac_functions = ["init", "send_packet", "packet_input", "on", "off", "channel_check_interval"]
func_blocks = ["Wait for Packet","Random Backoff","Send Packet"]
biglist = ["init", "send_packet", "packet_input", "on", "off", "channel_check_interval","Wait for Packet","Random Backoff","Send Packet"]


class MainWin(QMainWindow):
    def __init__(self):  
        super(MainWin,self).__init__()
        self.list_flag = [0]   
        self.net = nx.DiGraph()
##        self.count = 0
        self.flag = 0
        codefragment_copy = codefragment.copy()
        
        toolbar = self.addToolBar('Toolbar')
        btn1 = QPushButton('Nodes', self)
        btn2 = QPushButton('Edges', self)
        btn3 = QPushButton('Select', self)
        btn4 = QPushButton('Save File', self)    
        toolbar.addWidget(btn1)
        toolbar.addWidget(btn2)
        toolbar.addWidget(btn3)
        toolbar.addWidget(btn4)         

        btn4.clicked.connect(self.savebuttonClicked)    

        listsplitter = QFrame()
##        frame_1 = QFrame()
##        frame_1.setFrameShape(QFrame.StyledPanel)
        label1 = QLabel()
        label1.setText('MAC Functions:')
        label1.setStyleSheet('font: 18px;')
##        frame_1.addWidget(label1)
        
##        frame_2 = QFrame()
##        frame_2.setFrameShape(QFrame.StyledPanel)
        label2 = QLabel()
        label2.setText('Functional Blocks:')
        label2.setStyleSheet('font: 18px;')
##        frame_2.addWidget(label2)

        self.list1 = QListWidget()
        for i in range (6): self.list1.addItem(mac_functions[i])
##        frame_1.addWidget(self.frame1)
        self.list1.clicked.connect(self.listbox1_clicked)
        
        self.list2 = QListWidget()
        for i in range (3): self.list2.addItem(func_blocks[i])
##        frame_2.addWidget(self.frame2)
        self.list2.clicked.connect(self.listbox2_clicked)    
       
        left = NodeEditorWnd(self,self.list_flag,self.net)    

##        listsplitter = QSplitter(Qt.Vertical)
        splitter1 = QSplitter(Qt.Horizontal)

        layout = QVBoxLayout()

        layout.addWidget(label1)
##        layout.addStretch()
        layout.addWidget(self.list1)
        layout.addWidget(label2)
##        layout.addStretch()
        layout.addWidget(self.list2)

        listsplitter.setLayout(layout)
        
        splitter1.addWidget(left)
        splitter1.addWidget(listsplitter)
        splitter1.setSizes([800,30])
        
        self.statusBar().showMessage('Ready')
        self.showMaximized()
        self.setCentralWidget(splitter1)     
        self.setWindowTitle('Rapid MAC')
        self.show()
 
    def listbox1_clicked(self):
        item = self.list1.currentItem()
        if str(item.text()) == mac_functions[0]:
            self.list_flag[0] = 1
            self.statusBar().showMessage(mac_functions[0])
        if str(item.text()) == mac_functions[1]:
            self.list_flag[0] = 2
            self.statusBar().showMessage(mac_functions[1])
        if str(item.text()) == mac_functions[2]:
            self.list_flag[0] = 3
            self.statusBar().showMessage(mac_functions[2])
        if str(item.text()) == mac_functions[3]:
            self.list_flag[0] = 4
            self.statusBar().showMessage(mac_functions[3])
        if str(item.text()) == mac_functions[4]:
            self.list_flag[0] = 5
            self.statusBar().showMessage(mac_functions[4])
        if str(item.text()) == mac_functions[5]:
            self.list_flag[0] = 6
            self.statusBar().showMessage(mac_functions[5])

    def listbox2_clicked(self):
        item = self.list2.currentItem()
        if str(item.text()) == func_blocks[0]:
            self.list_flag[0] = 7
            self.statusBar().showMessage(func_blocks[0])
        if str(item.text()) == func_blocks[1]:
            self.list_flag[0] = 8
            self.statusBar().showMessage(func_blocks[1])
        if str(item.text()) == func_blocks[2]:
            self.list_flag[0] = 9
            self.statusBar().showMessage(func_blocks[2])

    def savebuttonClicked(self):
        sp = []
        codefrag1 = []
        codefrag2 = []
        codefrag3 = []
        codefrag4 = []
        
        self.draw_nxgraph()
        
        for i in range (len(codefragment)):
            k = codefragment[i]
            
            if k[0] in St_node: codefrag1.append(k)
            if k[0] in Wp_node: codefrag2.append(k)
            if k[0] in Rb_node: codefrag3.append(k)
            if k[0] in Sp_node: codefrag4.append(k)

        w = len(codefrag1)
        x = len(codefrag2)
        y = len(codefrag3)
        z = len(codefrag4)
            
        with open('codefragment.py','w') as myfile:
            if w != 0:
                for a in range (w):
                    k = codefrag1[a]
                    myfile.write("Start Node ---> ")
                    if k[1] in Wp_node:
                        myfile.write("Wait for Packet Node")
                    if k[1] in Rb_node:
                        myfile.write("Random Backoff Node")
                    if k[1] in Sp_node:
                        sp.append(k[1])
                        myfile.write("Send Packet Node")

            if x != 0:
                for b in range (x):
                    k = codefrag2[b]
                    myfile.write("\nWait for Packet Node ---> ")
                    if k[1] in Rb_node:
                        myfile.write("Random Backoff Node")
                    if k[1] in Sp_node:
                        sp.append(k[1])
                        myfile.write("Send Packet Node")

            if y != 0:
                for c in range (y):
                    k = codefrag3[c]
                    myfile.write("\nRandom Backoff Node ---> ")
                    if k[1] in Wp_node:
                        myfile.write("Wait for Packet Node")
                    if k[1] in Sp_node:
                        sp.append(k[1])
                        myfile.write("Send Packet Node")

            if z != 0:
                for d in range (z):
                    k = codefrag4[d]
                    myfile.write("\nSend Packet Node ---> ")
                    if k[1] in Wp_node:
                        myfile.write("Wait for Packet Node")
                    if k[1] in Rb_node:
                        myfile.write("Random Backoff Node")

            myfile.write('\n')
        with open('codefragment.py','a') as myfile:
            if (len(St_node)-w) > 0:
                for a in range (len(St_node)-w):
                    myfile.write("Start Node\n")

            if (len(Wp_node)-x) > 0:
                for b in range (len(Wp_node)-x):
                    myfile.write("Wait for Packet Node\n")

            if (len(Rb_node)-y) > 0:
                for c in range (len(Rb_node)-y):
                    myfile.write("Random Backoff Node\n")

            if (len(Sp_node)-z) > 0:
                for d in range (len(Sp_node)):
                    if Sp_node[d] in sp:
                        pass
                    else:
                        myfile.write("Send Packet Node\n")
  

    def draw_nxgraph(self):
##        if self.count > 1:
##            self.net.add_edges_from(codefragment)
        nx.draw(self.net,with_labels = True)
        
        plt.show()

    
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainWin()
    sys.exit(app.exec_())
    

