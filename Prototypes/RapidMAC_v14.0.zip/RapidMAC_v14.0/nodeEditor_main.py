# ! /usr/bin/env python 3.6.7
# -*- coding utf-8 -*-

import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5 import QtWidgets
from node_editor_wnd import NodeEditorWnd
from node_node import Node, codefragmenttext, St_node, Wp_node, Rb_node, Sp_node
from node_edge import Edge, codefragment
import networkx as nx
import matplotlib.pyplot as plt

listItems = ["Start Node","Wait for Packet","Random Backoff","Send Packet"]
#LIST_FLAG = 0

class MainWin(QMainWindow):
    def __init__(self):
        print('*----nodeEditor_main----*')  
        super(MainWin,self).__init__()
        self.list_flag = [0]   

        toolbar = self.addToolBar('Toolbar')
        btn1 = QPushButton('Nodes', self)
        btn2 = QPushButton('Edges', self)
        btn3 = QPushButton('Select', self)
        btn4 = QPushButton('Save File', self)    
        toolbar.addWidget(btn1)
        toolbar.addWidget(btn2)
        toolbar.addWidget(btn3)
        toolbar.addWidget(btn4)         

        btn4.clicked.connect(self.savebuttonClicked)    

        self.list = QListWidget()
        for i in range (4): self.list.addItem(listItems[i])
        self.list.clicked.connect(self.listbox_clicked)    
       
        left = NodeEditorWnd(self,self.list_flag)    

        splitter1 = QSplitter(Qt.Horizontal)
        splitter1.addWidget(left)
        splitter1.addWidget(self.list)
        splitter1.setSizes([300,50])
        
        self.statusBar().showMessage('Ready')
        self.showMaximized()
        self.setCentralWidget(splitter1)     
        self.setWindowTitle('Rapid MAC')
        self.show()
 
    def savebuttonClicked(self):
        print('len(codefragment) = ',len(codefragment))
        print('St_node:',St_node)
        print('Wp_node:',Wp_node)
        print('Rb_node:',Rb_node)
        print('Sp_node:',Sp_node)
        with open('codefragment.py','w') as myfile:
            for i in range (len(codefragment)):
                print('i=',i)
                k = codefragment[i]
                print('k:',k)
                print('k[0]:',k[0])
                print('k[1]:',k[1])
                if k[0] in St_node:
                    myfile.write("Start Node")
                if k[0] in Wp_node:
                    myfile.write("Wait for Packet Node")
                if k[0] in Rb_node:
                    myfile.write("Random Backoff Node")
                if k[0] in Sp_node: 
                    myfile.write("Send Packet Node")
                myfile.write(' ----> ')
                if k[1] in St_node                                                                                                                                                      :
                    myfile.write("Start Node")
                if k[1] in Wp_node:
                    myfile.write("Wait for Packet Node")
                if k[1] in Rb_node:
                    myfile.write("Random Backoff Node")
                if k[1] in Sp_node:
                    myfile.write("Send Packet Node")
                myfile.write('\n')
        self.draw_nxgraph()

    def draw_nxgraph(self):  
        G = nx.Graph()
        G.add_nodes_from(St_node)
        G.add_nodes_from(Wp_node)
        G.add_nodes_from(Rb_node)
        G.add_nodes_from(Sp_node)
        G.add_edges_from(codefragment)
        nx.draw(G,with_labels = True)
        print(nx.info(G))
        plt.show()
##        plt.savefig(labels.png)
       
    def listbox_clicked(self):
#        global LIST_FLAG
        item = self.list.currentItem()
        print(str(item.text()))
        if str(item.text()) == listItems[0]:
            self.list_flag[0] = 1
            self.statusBar().showMessage(listItems[0])
        if str(item.text()) == listItems[1]:
            self.list_flag[0] = 2
            self.statusBar().showMessage(listItems[1])
        if str(item.text()) == listItems[2]:
            self.list_flag[0] = 3
            self.statusBar().showMessage(listItems[2])
        if str(item.text()) == listItems[3]:
            self.list_flag[0] = 4
            self.statusBar().showMessage(listItems[3])
        print("clicked item:", self.list_flag)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainWin()
    sys.exit(app.exec_())
    

