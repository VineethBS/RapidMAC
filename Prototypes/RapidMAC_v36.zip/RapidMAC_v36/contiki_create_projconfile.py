    
# Project configuration file creation/updation

import os
import sys
##import shutil
import PyQt5
from PyQt5.QtWidgets import *
from PyQt5 import QtCore,QtWidgets,QtGui
from PyQt5.QtCore import *
from PyQt5.QtGui import *

projconf_line1 = "\n#ifndef __PROJECT_CONF_H__"
projconf_line2 = "\n#define __PROJECT_CONF_H__"
projconf_line3 = "\n\n\n#define NETSTACK_CONF_NETWORK rime_driver"
projconf_line4 = "\n#define NETSTACK_CONF_MAC     "
projconf_line5 = "\n#define NETSTACK_CONF_RDC     nullrdc_driver"
projconf_line6 = "\n#define NETSTACK_CONF_FRAMER  framer_802154"
projconf_line7 = "\n#define NETSTACK_CONF_RADIO   cc2420_driver"
projconf_line8 = "\n\n#undef  TIMESYNCH_CONF_ENABLED "
projconf_line9 = "\n#define TIMESYNCH_CONF_ENABLED 1"
projconf_line10 = "\n\n#define RF_CHANNEL 20"
projconf_line11 = "\n\n\n#endif /* __PROJECT_CONF_H__ */"


class CreateProjConfFile(QMainWindow):
    def __init__(self,project_dir_list,Driver_name_list):
        super().__init__()

        self.project_dir_list = project_dir_list
        self.Driver_name_list = Driver_name_list

        projconf = self.project_dir_list[0] + '/project-conf.h'
        
        print('projconf : ',projconf)

        with open (projconf,'w') as pfile:
            pfile.write(projconf_line1)
            pfile.write(projconf_line2)
            pfile.write(projconf_line3)
            pfile.write(projconf_line4 +self.Driver_name_list[0] + '\n')
            pfile.write(projconf_line5)
            pfile.write(projconf_line6)
            pfile.write(projconf_line7)
            pfile.write(projconf_line8)
            pfile.write(projconf_line9)
            pfile.write(projconf_line10)
            pfile.write(projconf_line11)
            pfile.write('\n\n')

            
            
                   
        
