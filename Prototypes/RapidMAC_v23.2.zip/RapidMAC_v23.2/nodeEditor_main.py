# ! /usr/bin/env python 3.6.7
# -*- coding utf-8 -*-

import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5 import QtWidgets
from node_editor_wnd import NodeEditorWnd
from node_node import Node, codefragmenttext, St_Init_node,St_SP_node,St_PI_node,St_On_node,St_Off_node,St_CCI_node, Wp_node, Rb_node, Sp_node
from node_edge import Edge, codefragment
from node_graphics_view import INIT_content,SP_content,PI_content,ON_content,OFF_content,CCI_content
import networkx as nx
import matplotlib.pyplot as plt

mac_functions = ["init", "send_packet", "packet_input", "on", "off", "channel_check_interval"]
func_blocks = ["Wait for Packet","Random Backoff","Send Packet","Return Value","Function Call","Variable Assignment"]
biglist = ["init", "send_packet", "packet_input", "on", "off", "channel_check_interval","Wait for Packet","Random Backoff","Send Packet"]
Flow1 = []
Flow2 = []
Flow3 = []
Flow4 = []
Flow5 = []
Flow6 = []

class MainWin(QMainWindow):
    def __init__(self):  
        super(MainWin,self).__init__()
        self.list_flag = [0]   
        self.net = nx.DiGraph()
##        self.count = 0
        self.node_content = "RAPID MAC - Main Window"
        self.flag = 0
        codefragment_copy = codefragment.copy()
        
        toolbar = self.addToolBar('Toolbar')
        btn1 = QPushButton('Nodes', self)
        btn2 = QPushButton('Edges', self)
        btn3 = QPushButton('Select', self)
        btn4 = QPushButton('Save File', self)    
        toolbar.addWidget(btn1)
        toolbar.addWidget(btn2)
        toolbar.addWidget(btn3)
        toolbar.addWidget(btn4)         

        btn4.clicked.connect(self.savebuttonClicked)    

        listsplitter = QFrame()
##        frame_1 = QFrame()
##        frame_1.setFrameShape(QFrame.StyledPanel)
        label1 = QLabel()
        label1.setText('MAC Functions:')
        label1.setStyleSheet('font: 18px;')
##        frame_1.addWidget(label1)
        
##        frame_2 = QFrame()
##        frame_2.setFrameShape(QFrame.StyledPanel)
        label2 = QLabel()
        label2.setText('Functional Blocks:')
        label2.setStyleSheet('font: 18px;')
##        frame_2.addWidget(label2)

        self.list1 = QListWidget()
        for i in range (6): self.list1.addItem(mac_functions[i])
##        frame_1.addWidget(self.frame1)
        self.list1.clicked.connect(self.listbox1_clicked)
        
        self.list2 = QListWidget()
        for i in range (6): self.list2.addItem(func_blocks[i])
##        frame_2.addWidget(self.frame2)
        self.list2.clicked.connect(self.listbox2_clicked)    
       
        left = NodeEditorWnd(self,self.list_flag,self.net,self.node_content)    

##        listsplitter = QSplitter(Qt.Vertical)
        splitter1 = QSplitter(Qt.Horizontal)

        layout = QVBoxLayout()

        layout.addWidget(label1)
##        layout.addStretch()
        layout.addWidget(self.list1)
        layout.addWidget(label2)
##        layout.addStretch()
        layout.addWidget(self.list2)

        listsplitter.setLayout(layout)
        
        splitter1.addWidget(left)
        splitter1.addWidget(listsplitter)
        splitter1.setSizes([800,30])
        
        self.statusBar().showMessage('Ready')
        self.showMaximized()
        self.setCentralWidget(splitter1)     
        self.setWindowTitle('Rapid MAC')
        self.show()
 
    def listbox1_clicked(self):
        item = self.list1.currentItem()
        if str(item.text()) == mac_functions[0]:
            self.list_flag[0] = 1
            self.statusBar().showMessage(mac_functions[0])
        if str(item.text()) == mac_functions[1]:
            self.list_flag[0] = 2
            self.statusBar().showMessage(mac_functions[1])
        if str(item.text()) == mac_functions[2]:
            self.list_flag[0] = 3
            self.statusBar().showMessage(mac_functions[2])
        if str(item.text()) == mac_functions[3]:
            self.list_flag[0] = 4
            self.statusBar().showMessage(mac_functions[3])
        if str(item.text()) == mac_functions[4]:
            self.list_flag[0] = 5
            self.statusBar().showMessage(mac_functions[4])
        if str(item.text()) == mac_functions[5]:
            self.list_flag[0] = 6
            self.statusBar().showMessage(mac_functions[5])

    def listbox2_clicked(self):
        item = self.list2.currentItem()
        if str(item.text()) == func_blocks[0]:
            self.list_flag[0] = 7
            self.statusBar().showMessage(func_blocks[0])
        if str(item.text()) == func_blocks[1]:
            self.list_flag[0] = 8
            self.statusBar().showMessage(func_blocks[1])
        if str(item.text()) == func_blocks[2]:
            self.list_flag[0] = 9
            self.statusBar().showMessage(func_blocks[2])
        if str(item.text()) == func_blocks[3]:
            self.list_flag[0] = 10
            self.statusBar().showMessage(func_blocks[3])
        if str(item.text()) == func_blocks[4]:
            self.list_flag[0] = 11
            self.statusBar().showMessage(func_blocks[4])
        if str(item.text()) == func_blocks[5]:
            self.list_flag[0] = 12
            self.statusBar().showMessage(func_blocks[5])

    def savebuttonClicked(self):
        codefragment_copy = []
##        sp = []
##        codefrag1 = []
##        codefrag2 = []
##        codefrag3 = []
##        codefrag4 = []
        print('Code Fragment:', codefragment)
        print('len(codefragment) = ',len(codefragment))
        print('St_Init_node:',St_Init_node)
        print('St_SP_node:',St_SP_node)
        print('St_PI_node:',St_PI_node)
        print('St_On_node:',St_On_node)
        print('St_Off_node:',St_Off_node)
        print('St_CCI_node:',St_CCI_node)
        print('Wp_node:',Wp_node)
        print('Rb_node:',Rb_node)
        print('Sp_node:',Sp_node)
        self.draw_nxgraph()
        
        # check if all the MAC Function nodes are created
        st1 = len(St_Init_node)
        st2 = len(St_SP_node)
        st3 = len(St_PI_node)
        st4 = len(St_On_node)
        st5 = len(St_Off_node)
        st6 = len(St_CCI_node)

        for i in range (len(codefragment)):
            codefragment_copy.append(codefragment[i])
        print('Codefragment_copy = ',codefragment_copy)
        
        if st1 == 1 and st2 == 1 and st3 == 1 and st4 == 1 and st5 == 1 and st6 == 1:
            for i in range (len(codefragment_copy)):
                print("codefragment_copy = ",codefragment_copy)
                print("i = ",i)
                k = codefragment_copy[0]
                print (k)
                if k[0] in St_Init_node:
                    Flow1.append(k)
                    codefragment_copy.remove(k)
                    for j in range (len(codefragment_copy)):
                        k1 = codefragment_copy[j]
                        if k1[0] == k[1]:
                            Flow1.append(k1)
                            codefragment_copy.remove(k1)
                            for m in range (len(codefragment_copy)):
                                k2 = codefragment_copy[m]
                                if k2[0] == k1[1]:
                                    Flow1.append(k2)
                                    codefragment_copy.remove(k2)
                                    break
                            break
##                    self.writefile(Flow1)            
                if k[0] in St_SP_node:
                    Flow2.append(k)
                    codefragment_copy.remove(k)
                    for j in range (len(codefragment_copy)):
                        k1 = codefragment_copy[j]
                        if k1[0] == k[1]:
                            Flow2.append(k1)
                            codefragment_copy.remove(k1)
                            for m in range (len(codefragment_copy)):
                                k2 = codefragment_copy[m]
                                if k2[0] == k1[1]:
                                    Flow2.append(k2)
                                    codefragment_copy.remove(k2)
                                    break
                            break
##                    self.writefile(Flow2)      
                if k[0] in St_PI_node:
                    Flow3.append(k)
                    codefragment_copy.remove(k)
                    for j in range (len(codefragment_copy)):
                        k1 = codefragment_copy[j]
                        if k1[0] == k[1]:
                            Flow3.append(k1)
                            codefragment_copy.remove(k1)
                            for m in range (len(codefragment_copy)):
                                k2 = codefragment_copy[m]
                                if k2[0] == k1[1]:
                                    Flow3.append(k2)
                                    codefragment_copy.remove(k2)
                                    break
                            break
##                    self.writefile(Flow3)      
                if k[0] in St_On_node:
                    Flow4.append(k)
                    codefragment_copy.remove(k)
                    for j in range (len(codefragment_copy)):
                        k1 = codefragment_copy[j]
                        if k1[0] == k[1]:
                            Flow4.append(k1)
                            codefragment_copy.remove(k1)
                            for m in range (len(codefragment_copy)):
                                k2 = codefragment_copy[m]
                                if k2[0] == k1[1]:
                                    Flow4.append(k2)
                                    codefragment_copy.remove(k2)
                                    for n in range (len(codefragment_copy)):
                                        k3 = codefragment_copy[n]
                                        if k3[0] == k2[1]:
                                            Flow4.append(k3)
                                            codefragment_copy.remove(k3)
                                            break
                                    break
                            break
##                    self.writefile(Flow4)      
                if k[0] in St_Off_node:
                    Flow5.append(k)
                    codefragment_copy.remove(k)
                    for j in range (len(codefragment_copy)):
                        k1 = codefragment_copy[j]
                        if k1[0] == k[1]:
                            Flow5.append(k1)
                            codefragment_copy.remove(k1)
                            for m in range (len(codefragment_copy)):
                                k2 = codefragment_copy[m]
                                if k2[0] == k1[1]:
                                    Flow5.append(k2)
                                    codefragment_copy.remove(k2)
                                    for n in range (len(codefragment_copy)):
                                        k3 = codefragment_copy[n]
                                        if k3[0] == k2[1]:
                                            Flow5.append(k3)
                                            codefragment_copy.remove(k3)
                                            break
                                    break
                            break
##                    self.writefile(Flow5)      
                if k[0] in St_CCI_node:
                    Flow6.append(k)
                    codefragment_copy.remove(k)
                    for j in range (len(codefragment_copy)):
                        k1 = codefragment_copy[j]
                        if k1[0] == k[1]:
                            Flow6.append(k1)
                            codefragment_copy.remove(k1)
                            for m in range (len(codefragment_copy)):
                                k2 = codefragment_copy[m]
                                if k2[0] == k1[1]:
                                    Flow6.append(k2)
                                    codefragment_copy.remove(k2)
                                    for n in range (len(codefragment_copy)):
                                        k3 = codefragment_copy[n]
                                        if k3[0] == k2[1]:
                                            Flow6.append(k3)
                                            codefragment_copy.remove(k3)
                                            break
                                    break
                            break
##                    self.writefile(Flow6)      
                if (len(codefragment_copy)) != 0:
                    continue
                else:
                    break
##                i=0   
            print("Flow1 = ",Flow1)
            print("Flow2 = ",Flow2)
            print("Flow3 = ",Flow3)
            print("Flow4 = ",Flow4)
            print("Flow5 = ",Flow5)
            print("Flow6 = ",Flow6)
            with open ('codefragment.c','w') as myfile:
                for a in range (len(Flow1)):
                    A = Flow1[a]
##                    print("a = ",a, 'A = ',A)
                    self.node1 = A[0]
                    self.node2 = A[1]
                    self.writefile()
                myfile.write("\n/*-------------------------------------------------------------------------------------------------*/\n")
                for a in range (len(Flow2)):
                    A = Flow2[a]
##                    print("a = ",a, 'A = ',A)
                    self.node1 = A[0]
                    self.node2 = A[1]
                    self.writefile()
                myfile.write("\n/*-------------------------------------------------------------------------------------------------*/\n")
                for a in range (len(Flow3)):
                    A = Flow3[a]
##                    print("a = ",a, 'A = ',A)
                    self.node1 = A[0]
                    self.node2 = A[1]
                    self.writefile()
                myfile.write("\n/*-------------------------------------------------------------------------------------------------*/\n")
                for a in range (len(Flow4)):
                    A = Flow4[a]
##                    print("a = ",a, 'A = ',A)
                    self.node1 = A[0]
                    self.node2 = A[1]
                    self.writefile()
                myfile.write("\n/*-------------------------------------------------------------------------------------------------*/\n")
                for a in range (len(Flow5)):
                    A = Flow5[a]
##                    print("a = ",a, 'A = ',A)
                    self.node1 = A[0]
                    self.node2 = A[1]
                    self.writefile()
                myfile.write("\n/*-------------------------------------------------------------------------------------------------*/\n")
                for a in range (len(Flow6)):
                    A = Flow6[a]
##                    print("a = ",a, 'A = ',A)
                    self.node1 = A[0]
                    self.node2 = A[1]
                    self.writefile()
                myfile.write("\n/*-------------------------------------------------------------------------------------------------*/\n")
                    
    def writefile(self):
        with open ('codefragment.c','a') as myfile:
            if self.node1 in St_Init_node:
##                myfile.write("\n\nInit Node")
                myfile.write(INIT_content)
            if self.node1 in St_SP_node:
##                myfile.write("\n\nStart_Send_Packet Node")
                myfile.write(SP_content)
            if self.node1 in St_PI_node:
##                myfile.write("\n\nStart_Packet_Input Node")
                myfile.write(PI_content)
##                myfile.write("\n/*---------------------------------------------------------------------------*/")
            if self.node1 in St_On_node:
##                myfile.write("\n\nStart_ON_Node")
                myfile.write(ON_content)
##                myfile.write("\n/*---------------------------------------------------------------------------*/")
            if self.node1 in St_Off_node:
##                myfile.write("\n\nStart_OFF_Node")
                myfile.write(OFF_content)
##                myfile.write("\n/*---------------------------------------------------------------------------*/")
            if self.node1 in St_CCI_node:
##                myfile.write("\n\nStart_Channel_Check_Interval Node")
                myfile.write(CCI_content)
##                myfile.write("\n/*---------------------------------------------------------------------------*/")
            if self.node1 in Wp_node:
                myfile.write("\nWait for Packet Node")
            if self.node1 in Rb_node:
                myfile.write("\nRandom Backoff Node")
    ##            if self.node1 in Sp_node:
    ##                myfile.write("Send Packet Node")
            myfile.write(" >>>>>>>>> ")
            if self.node2 in Wp_node:
                myfile.write("Wait for Packet Node")
            if self.node2 in Rb_node:
                myfile.write("Random Backoff Node")
            if self.node2 in Sp_node:
                myfile.write("Send Packet Node") 

    def draw_nxgraph(self):
##        if self.count > 1:
##            self.net.add_edges_from(codefragment)
        nx.draw(self.net,with_labels = True)
        print(nx.info(self.net))
        plt.show()

    
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainWin()
    sys.exit(app.exec_())
    

