
/*-------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------*/
r Packet Node >>>>>>>>> Random Backoff Node
Random Backoff Node >>>>>>>>> Send Packet Nodestatic int
on(void)
{
	return NETSTACK_RDC.on();
} >>>>>>>>> Wait for Packet Node
Wait for Packet Node >>>>>>>>> Random Backoff Node
Random Backoff Node >>>>>>>>> Send Packet Nodestatic int
off(int keep_radio_on)
{
	return NETSTACK_RDC.off(keep_radio_on);
} >>>>>>>>> Wait for Packet Node
Wait for Packet Node >>>>>>>>> Random Backoff Node
Random Backoff Node >>>>>>>>> Send Packet Nodestatic unsigned short
channel_check_interval(void)
{
	return 0;
} >>>>>>>>> Wait for Packet Node
Wait for Packet Node >>>>>>>>> Random Backoff Node
Random Backoff Node >>>>>>>>> Send Packet Node