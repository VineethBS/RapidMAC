from node_graphics_node import QDMGraphicsNode
from node_content_widget import QDMNodeContentWidget
from node_graphics_scene import QDMGraphicsScene
from node_socket import Socket
from node_socket import *

codefragmenttext = []
nodeslist = []    # list of nodes
newnodes_list = []  # list of new nodes
p_nodeslist = []  # list of node ids
Attributes = {}
##Edge_attributes = {}

St_node = []
St_Init_node = []
St_SP_node = []
St_PI_node = []
St_On_node = []
St_Off_node = []
St_CCI_node = []
Wp_node = []
Rb_node = []
Sp_node = []
Va_node = []
Fc_node = []
Rv_node = []
Cust_node = []
FunDef_node = []
VarDef_node = []
MacroDef_node = []
Driver_node = []
Header_node = []


class Node():
    def __init__(self,scene,title="New Node",inputs=[], outputs=[]):
        self.scene = scene
        self.title = title
        self.nodeinputs = inputs
        self.nodeoutputs = outputs
        self.content = QDMNodeContentWidget()
        self.grNode = QDMGraphicsNode(self)
        self.scene.addNode(self)
        self.scene.grScene.addItem(self.grNode)
        
        self.grScene = QDMGraphicsScene(self.scene)
        self.socket_spacing = 22

        self.inputs = []
        self.outputs = []

        counter = 0
        for item in self.nodeinputs:
            socket = Socket(node=self, index=counter, position=LEFT_TOP, socket_type=item)  
            counter += 1
            self.inputs.append(socket)
            
            inpos = socket.getSocketPosition()
            inpos[0] += socket.node.grNode.pos().x()
            inpos[1] += socket.node.grNode.pos().y()

        counter = 0
        for item in self.nodeoutputs:
            socket = Socket(node=self, index=counter, position=RIGHT_TOP,socket_type = item)
            counter += 1
            self.outputs.append(socket)

            outpos = socket.getSocketPosition()
            outpos[0] += socket.node.grNode.pos().x()
            outpos[1] += socket.node.grNode.pos().y()

    def __str__(self):
        return "<Node %s..%s>" % (hex(id(self))[2:5], hex(id(self))[-3:])

    @property
    def pos(self):
        return self.grNode.pos()
    def setPos(self, x, y):
        self.grNode.setPos(x, y)

    def getPos(self,x,y):
        self.grNode.getPos(x,y)
        

    def getSocketPosition(self, index, position):
        x = 0 if position in (LEFT_TOP, LEFT_BOTTOM) else self.grNode.width
        if position in (LEFT_BOTTOM, RIGHT_BOTTOM):
            y = self.grNode.height - self.grNode.edge_size - self.grNode._padding - index * self.socket_spacing
        else:
            y = self.grNode.title_height + self.grNode._padding + self.grNode.edge_size + index * self.socket_spacing

        return [x, y]

    def updateConnectedEdges(self):
        
        for socket in self.inputs + self.outputs:
            if socket.hasEdge():
                socket.edge.updatePositions()

                if socket in self.inputs:
                    self.edge_start_node = hex(id(socket.node.grNode))
                    self.index1 = socket.index
                    self.position1 = socket.position
                    self.socket_type1 = socket.socket_type
                if socket in self.outputs:
                    self.edge_end_node = hex(id(socket.node.grNode))
                    self.index2 = socket.index
                    self.position2 = socket.position
                    self.socket_type2 = socket.socket_type
            

class Start_Node_Init(Node):
    def __init__(self,node_content,position,scene,title="Init",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Init",inputs=[], outputs=[1])
        St_Init_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}


class Start_Node_SP(Node):
    def __init__(self,node_content,position,scene,title="Send_Packet",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Send_Packet",inputs=[], outputs=[1])
        St_SP_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}


class Start_Node_PI(Node):
    def __init__(self,node_content,position,scene,title="Packet_Input",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Packet_Input",inputs=[], outputs=[1])
        St_PI_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}


class Start_Node_On(Node):
    def __init__(self,node_content,position,scene,title="On",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="On",inputs=[], outputs=[1])
        St_On_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}

class Start_Node_Off(Node):
    def __init__(self,node_content,position,scene,title="Off",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Off",inputs=[], outputs=[1])
        St_Off_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}

        
class Start_Node_CCI(Node):
    def __init__(self,node_content,position,scene,title="Channel_check_Interval",inputs=[],outputs=[]):
        
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Channel_check_Interval",inputs=[], outputs=[1])
        St_CCI_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}

class Waitforpkt_Node(Node):
    def __init__(self,node_content,position,scene,title="Wait for packet Node",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Wait for packet Node",inputs=[1], outputs=[1])
        Wp_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}
       

class Randombackoff_Node(Node):
    def __init__(self,node_content,position,scene,title="Randombackoff Node",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Random backoff Node",inputs=[1,2], outputs=[1])
        Rb_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}


class Sendpacket_Node(Node):
    def __init__(self,node_content,position,scene,title="Sendpacket Node",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        print('\nNodeposition:',self.position)
        Node.__init__(self,scene,title="Send packet Node",inputs=[1,2,3], outputs=[1])
        Sp_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}


class ReturnValue_Node(Node):
    def __init__(self,node_content,position,scene,title="Return Value Node",inputs=[],outputs=[]):
        
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Return Value Node",inputs=[1], outputs=[])
        Rv_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}


class FunctionCall_Node(Node):
    def __init__(self,node_content,position,scene,title="Function Call Node",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Function Call Node",inputs=[1], outputs=[1])
        Fc_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}


class VariableAssign_Node(Node):
    def __init__(self,node_content,position,scene,title="Variable Assignment Node",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Variable Assignment Node",inputs=[1], outputs=[1])
        Va_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}


class CustomCode_Node(Node):
    def __init__(self,node_content,position,scene,title="Custom Code Node",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Custom Code Node",inputs=[1], outputs=[1])
        Cust_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}

class FunctionDefinition_Node(Node):
    def __init__(self,node_content,position,scene,title="Function Definition Node",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Function Definition Node",inputs=[], outputs=[])
        FunDef_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}

class VariableDefinition_Node(Node):
    def __init__(self,node_content,position,scene,title="Variable Definition Node",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Variable Definition Node",inputs=[], outputs=[])
        VarDef_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}

class MacroDefinition_Node(Node):
    def __init__(self,node_content,position,scene,title="Macro Definition Node",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Macro Definition Node",inputs=[], outputs=[])
        MacroDef_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}


class Driver_Node(Node):
    def __init__(self,node_content,position,scene,title="Driver Node",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Driver Node",inputs=[],outputs=[])
        Driver_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content,'mac_drv_name':'mac_driver_name'}


class Header_Node(Node):
    def __init__(self,node_content,position,scene,title="Header Node",inputs=[],outputs=[]):
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Header Node",inputs=[],outputs=[])
        Header_node.append(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        newnodes_list.append(self)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}        




