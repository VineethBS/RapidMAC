    
# Project configuration file creation/updation

import os
import sys
##import shutil
import PyQt5
from PyQt5.QtWidgets import *
from PyQt5 import QtCore,QtWidgets,QtGui
from PyQt5.QtCore import *
from PyQt5.QtGui import *

projconf_line1 = "\n\n\n"
projconf_line2 = "#define NETSTACK_CONF_MAC "
projconf_line3 = "#define NETSTACK_CONF_RDC nullrdc_driver\n"
projconf_line4 = "//#define NETSTACK_CONF_FRAMER framer_nullmac\n"

class CreateProjConfFile(QMainWindow):
    def __init__(self,project_dir_list,Driver_name_list):
        super().__init__()

        self.project_dir_list = project_dir_list
        self.Driver_name_list = Driver_name_list

        projconf = self.project_dir_list[0] + '/project-conf.h'
        
        print('projconf : ',projconf)

        with open (projconf,'w') as pfile:
            pfile.write(projconf_line1)
            pfile.write(projconf_line2 +self.Driver_name_list[0] + '\n')
            pfile.write(projconf_line3)
            pfile.write(projconf_line4)
                   
        
