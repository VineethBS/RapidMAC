    
# Header file creation

import os
import sys
##import shutil
import PyQt5
from PyQt5.QtWidgets import *
from PyQt5 import QtCore,QtWidgets,QtGui
from PyQt5.QtCore import *
from PyQt5.QtGui import *

Header_line1 = "/*"
Header_line2 = " * Copyright (c) 2007, Swedish Institute of Computer Science."
Header_line3 = " * All rights reserved."
Header_line4 = " * "
Header_line5 = " * Redistribution and use in source and binary forms, with or without"
Header_line6 = " * modification, are permitted provided that the following conditions"
Header_line7 = " * are met:"
Header_line8 = " * 1. Redistributions of source code must retain the above copyright "
Header_line9 = " *    notice, this list of conditions and the following disclaimer. "
Header_line10 = " * 2. Redistributions in binary form must reproduce the above copyright "
Header_line11 = " *    notice, this list of conditions and the following disclaimer in the"
Header_line12 = " *    documentation and/or other materials provided with the distribution."
Header_line13 = " * 3. Neither the name of the Institute nor the names of its contributors"
Header_line14 = " *    may be used to endorse or promote products derived from this software"
Header_line15 = " *    without specific prior written permission."
Header_line16 = " *"
Header_line17 = " * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND"
Header_line18 = " * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE"
Header_line19 = " * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE"
Header_line20 = " * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE"
Header_line21 = " * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL"
Header_line22 = " * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS"
Header_line23 = " * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)"
Header_line24 = " * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT"
Header_line25 = " * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY"
Header_line26 = " * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF"
Header_line27 = " * SUCH DAMAGE."
Header_line28 = " *"
Header_line29 = " * This file is part of the Contiki operating system."
Header_line30 = " *"
Header_line31 = " */"

Author_line1 = "/**"
Author_line2 = " * "+"\\"+"file\n"
Author_line3 = " *         A MAC stack protocol that performs retransmissions when the"
Author_line4 = " *         underlying MAC layer has problems with collisions"
Author_line5 = "\n * "+"\\"+"author\n"
Author_line6 = " *         Adam Dunkels <adam@sics.se>"
Author_line7 = " */"

class CreateHeaderfile(QMainWindow):
    def __init__(self,Driver_name_list):
        super().__init__()

        self.Driver_name_list = Driver_name_list

##        print('self.Driver_name_list[0] : ',self.Driver_name_list[0])
        
##        os.chdir(r"/home/sherine/contiki/core/net/mac")
        
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        self.HfileName = QFileDialog.getSaveFileName(self,"Save Header file (.h)...", "", "All Files (*.*);;header files (*.h)", options=options)
##        print('__self.HfileName :',self.HfileName)

        with open (self.HfileName[0],'w') as hfile:
##            print('self.HfileName :',self.HfileName[0])
            hfile.write(Header_line1+'\n'+Header_line2+'\n'+Header_line3+'\n'+Header_line4+'\n'+Header_line5+'\n'+Header_line6+'\n'+Header_line7+'\n'+Header_line8+'\n'+
                        Header_line9+'\n'+Header_line10+'\n'+Header_line11+'\n'+Header_line12+'\n'+Header_line13+'\n'+Header_line14+'\n'+Header_line15+'\n'+
                        Header_line16+'\n'+Header_line17+'\n'+Header_line18+'\n'+Header_line19+'\n'+Header_line20+'\n'+Header_line21+'\n')
            hfile.write(Header_line22+'\n'+Header_line23+'\n'+Header_line24+'\n'+Header_line25+'\n'+Header_line26+'\n'+Header_line27+'\n'+Header_line28+'\n'+
                        Header_line29+'\n'+Header_line30+'\n'+Header_line31+'\n')
            hfile.write('\n\n')
            hfile.write(Author_line1+'\n'+Author_line2+'\n'+Author_line3+'\n'+Author_line4+'\n'+Author_line5+'\n'+Author_line6+'\n'+Author_line7+'\n')
            hfile.write('\n')
            hfile_name = os.path.splitext(os.path.basename(self.HfileName[0]))[0]
##            print(hfile_name)
            hfile.write('#ifndef '+hfile_name.upper()+'_H_\n')
            hfile.write('#define '+hfile_name.upper()+'_H_\n')
            hfile.write('\n')
            hfile.write('#include "net/mac/mac.h"\n')
            hfile.write('#include "dev/radio.h"\n')
            hfile.write('\n')
            hfile.write('extern const struct mac_driver ')
            hfile.write(self.Driver_name_list[0] + ';\n')
            hfile.write('\n#endif /* '+hfile_name.upper()+'_H_ */'+'\n\n')
##        source = self.HfileName
##        destination = '/home/sherine/contiki/core/net/mac'
##        print('destination: ',destination)
##        shutil.copy(self.HfileName, destination)
        
        
