Start Node ----> Send Packet Node
Wait for Packet Node
Random Backoff Node
