from node_graphics_node import QDMGraphicsNode
from node_content_widget import QDMNodeContentWidget
from node_socket import *
import networkx as nx
import matplotlib.pyplot as plt

codefragmenttext = []
St_node = []
Wp_node = []
Rb_node = []
Sp_node = []

class Node():
    def __init__(self,scene,title="New Node",inputs=[], outputs=[]):
        print('*----node_node----*')
        self.scene = scene
        self.title = title
        self.nodeinputs = inputs
        self.nodeoutputs = outputs

        self.content = QDMNodeContentWidget()
        self.grNode = QDMGraphicsNode(self)
        self.scene.addNode(self)
        self.scene.grScene.addItem(self.grNode)

        self.socket_spacing = 22

        self.inputs = []
        self.outputs = []
     
        counter = 0
        for item in self.nodeinputs:
            socket = Socket(node=self, index=counter, position=LEFT_TOP, socket_type=item)  
            counter += 1
            self.inputs.append(socket)

        counter = 0
        for item in self.nodeoutputs:
            socket = Socket(node=self, index=counter, position=RIGHT_TOP,socket_type = item)
            counter += 1
            self.outputs.append(socket)

    def __str__(self):
        return "<Node %s..%s>" % (hex(id(self))[2:5], hex(id(self))[-3:])

    @property
    def pos(self):
        return self.grNode.pos()
    def setPos(self, x, y):
        self.grNode.setPos(x, y)

    def getSocketPosition(self, index, position):
        print("---node_node.py - getSocketPosition")
        x = 0 if position in (LEFT_TOP, LEFT_BOTTOM) else self.grNode.width
        if position in (LEFT_BOTTOM, RIGHT_BOTTOM):
            print("---node_node.py - if position")
            y = self.grNode.height - self.grNode.edge_size - self.grNode._padding - index * self.socket_spacing
        else :
            print("---node_node.py - else position")
            y = self.grNode.title_height + self.grNode._padding + self.grNode.edge_size + index * self.socket_spacing

        return [x, y]

    def updateConnectedEdges(self):
        print("---node_node.py - updateConnectedEdges")
        for socket in self.inputs + self.outputs:
            if socket.hasEdge():
                print("---node_node.py - if socket.hasEdge()")
                socket.edge.updatePositions()

class Start_Node(Node):
    def __init__(self,net,scene,title="Start Node",inputs=[],outputs=[]):
        print("---node_node.py - Start Node")
        self.net = net
        Node.__init__(self,scene,title="Start Node",inputs=[], outputs=[1])
        St_node.append(hex(id(self.grNode)))
        self.net.add_node(hex(id(self.grNode)))
        codefragmenttext.append("Start Node")

class Waitforpkt_Node(Node):
    def __init__(self,net,scene,title="Wait for packet Node",inputs=[],outputs=[]):
        print("---node_node.py - Wait for packet Node")
        self.net = net
        Node.__init__(self,scene,title="Wait for packet Node",inputs=[1], outputs=[1])
        Wp_node.append(hex(id(self.grNode)))
        self.net.add_node(hex(id(self.grNode)))
        codefragmenttext.append("Wait for packet Node")
        

class Randombackoff_Node(Node):
    def __init__(self,net,scene,title="Randombackoff Node",inputs=[],outputs=[]):
        print("---node_node.py - Randombackoff_Node")
        self.net = net
        Node.__init__(self,scene,title="Random backoff Node",inputs=[1,2], outputs=[1])
        Rb_node.append(hex(id(self.grNode)))
        self.net.add_node(hex(id(self.grNode)))
        codefragmenttext.append("Random Backoff Node")

class Sendpacket_Node(Node):
    def __init__(self,net,scene,title="Sendpacket Node",inputs=[],outputs=[]):
        print("---node_node.py - Sendpacket_Node")
        self.net = net
        Node.__init__(self,scene,title="Send packet Node",inputs=[1,2,3], outputs=[1])
        Sp_node.append(hex(id(self.grNode)))
        self.net.add_node(hex(id(self.grNode)))
        codefragmenttext.append("Sendpacket Node")


         
