# ! /usr/bin/env python 3.6.7
# -*- coding utf-8 -*-

import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5 import QtWidgets
from node_editor_wnd import NodeEditorWnd
from node_node import Node, codefragmenttext, St_node, Wp_node, Rb_node, Sp_node
from node_edge import Edge, codefragment
import networkx as nx
import matplotlib.pyplot as plt

listItems = ["Start Node","Wait for Packet","Random Backoff","Send Packet"]
new_list = []


class MainWin(QMainWindow):
    def __init__(self):
        print('*----nodeEditor_main----*')  
        super(MainWin,self).__init__()
        self.list_flag = [0]   
        self.net = nx.Graph()
        self.count = 0
        self.flag = 0
        toolbar = self.addToolBar('Toolbar')
        btn1 = QPushButton('Nodes', self)
        btn2 = QPushButton('Edges', self)
        btn3 = QPushButton('Select', self)
        btn4 = QPushButton('Save File', self)    
        toolbar.addWidget(btn1)
        toolbar.addWidget(btn2)
        toolbar.addWidget(btn3)
        toolbar.addWidget(btn4)         

        btn4.clicked.connect(self.savebuttonClicked)    

        self.list = QListWidget()
        for i in range (4): self.list.addItem(listItems[i])
        self.list.clicked.connect(self.listbox_clicked)    
       
        left = NodeEditorWnd(self,self.list_flag,self.net)    

        splitter1 = QSplitter(Qt.Horizontal)
        splitter1.addWidget(left)
        splitter1.addWidget(self.list)
        splitter1.setSizes([300,50])
        
        self.statusBar().showMessage('Ready')
        self.showMaximized()
        self.setCentralWidget(splitter1)     
        self.setWindowTitle('Rapid MAC')
        self.show()
 
    def savebuttonClicked(self):
        self.draw_nxgraph()
        
        print('len(codefragment) = ',len(codefragment))
        print('St_node:',St_node)
        print('Wp_node:',Wp_node)
        print('Rb_node:',Rb_node)
        print('Sp_node:',Sp_node)
        with open('codefragment.py','w') as myfile:
            for i in range (len(codefragment)):
                k = codefragment[i]
                new_list.append(k[0])
                if k[0] in St_node:
                    myfile.write("Start Node")
                if k[0] in Wp_node:
                    myfile.write("Wait for Packet Node")
                if k[0] in Rb_node:
                    myfile.write("Random Backoff Node")
                if k[0] in Sp_node: 
                    myfile.write("Send Packet Node")
                myfile.write(' ----> ')
                new_list.append(k[1])
                if k[1] in St_node                                                                                                                                                      :
                    myfile.write("Start Node")
                if k[1] in Wp_node:
                    myfile.write("Wait for Packet Node")
                if k[1] in Rb_node:
                    myfile.write("Random Backoff Node")
                if k[1] in Sp_node:
                    myfile.write("Send Packet Node")
                myfile.write('\n')
        with open('codefragment.py','a') as myfile:
            if len(St_node) > 0:
                for a in range (len(St_node)):
                    for j in range (len(new_list)):
                        if St_node[a] != new_list[j]:
                            self.flag = 1
                        else:
                            self.flag = 0
                            break
                if self.flag == 1: myfile.write("Start Node\n")
            if len(Wp_node) > 0:
                for b in range (len(Wp_node)):
                    for j in range (len(new_list)):
                        if Wp_node[b] != new_list[j]:
                            self.flag = 1
                        else:
                            self.flag = 0
                            break
                if self.flag == 1: myfile.write("Wait for Packet Node\n")
            if len(Rb_node) > 0:
                for c in range (len(Rb_node)):
                    for j in range (len(new_list)):
                        if Rb_node[c] != new_list[j]:
                            self.flag = 1
                        else:
                            self.flag = 0
                            break
                if self.flag == 1: myfile.write("Random Backoff Node\n")
            if len(Sp_node) > 0:
                for d in range (len(Sp_node)):
                    for j in range (len(new_list)):
                        if Sp_node[d] != new_list[j]:
                            self.flag = 1
                        else:
                            self.flag = 0
                            break
                if self.flag == 1: myfile.write("Send Packet Node\n")
                            

    def draw_nxgraph(self):
        if self.count > 1:
            self.net.add_edges_from(codefragment)
        nx.draw(self.net,with_labels = True)
        print(nx.info(self.net))
        print('nx graph...Nodes')
        print(self.net.nodes())
        print('nx graph...Edges')
        print(self.net.edges())
        plt.show()

    def listbox_clicked(self):
        item = self.list.currentItem()
        if str(item.text()) == listItems[0]:
            self.list_flag[0] = 1
            self.statusBar().showMessage(listItems[0])
        if str(item.text()) == listItems[1]:
            self.list_flag[0] = 2
            self.statusBar().showMessage(listItems[1])
        if str(item.text()) == listItems[2]:
            self.list_flag[0] = 3
            self.statusBar().showMessage(listItems[2])
        if str(item.text()) == listItems[3]:
            self.list_flag[0] = 4
            self.statusBar().showMessage(listItems[3])


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainWin()
    sys.exit(app.exec_())
    

