import PyQt5
import sys
import pickle
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtWidgets import QGraphicsView,QGraphicsScene,QMessageBox,QApplication,QWidget,QInputDialog,QLineEdit,QAction,\
                            QPlainTextEdit,QTextEdit,QVBoxLayout,QFrame,QPushButton,qApp
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.Qt import QApplication, QClipboard
from node_graphics_node import QDMGraphicsNode
from node_graphics_socket import QDMGraphicsSocket
from node_graphics_edge import QDMGraphicsEdge,QDMGraphicsEdgeDirect,QDMGraphicsEdgeBezier
from node_graphics_scene import QDMGraphicsScene
from node_socket import Socket,Node_sockets
from node_edge import Edge, EDGE_TYPE_BEZIER,Edge_attributes,socket_attrs
from node_node import Node,Start_Node_Init,Start_Node_SP,Start_Node_PI,Start_Node_On,Start_Node_Off,Start_Node_CCI
from node_node import Waitforpkt_Node,Randombackoff_Node,Sendpacket_Node,ReturnValue_Node,FunctionCall_Node,VariableAssign_Node,CustomCode_Node
from node_node import FunctionDefinition_Node,VariableDefinition_Node,MacroDefinition_Node,Driver_Node,Header_Node
from node_node import Rv_node, Cust_node,FunDef_node,VarDef_node, MacroDef_node,Driver_node,Header_node,Attributes,nodeslist,p_nodeslist,newnodes_list
from node_socket import *
from node_edge import *
import networkx as nx


INIT_content1 = "static void\ninit(void)\n{\n"
INIT_content2 = "\n}"
SP_content1 = "static void \nsend_packet(mac_callback_t sent, void *ptr)\n{\n"
SP_content_custom = "\n\tp.sent = sent;\
                \n\tp.ptr = ptr;\n\tclock_time_t delay = random_rand() % CLOCK_SECOND;\
                \n\tPRINTF('Simple-ALOHA : at %u scheduling transmission in %u ticks\\n', (unsigned) clock_time(),(unsigned) delay);\
                \n\tctimer_set(&transmit_timer, delay, _send_packet, &p);\n\tsent(ptr, MAC_TX_DEFERRED, 1);"
SP_content2 = "\n}"
PI_content1 = "static void \npacket_input(void)\n{\n"
PI_content_custom = "\tNETSTACK_LLSEC.input();"
PI_content2 = "\n}"
ON_content1 = "static int\non(void)\n{\n"
ON_content2 = ";\n}"
OFF_content1 = "static int\noff(int keep_radio_on)\n{\n"
OFF_content2 = ";\n}"
CCI_content1 = "static unsigned short\nchannel_check_interval(void)\n{\n"
CCI_content2 = ";\n}"   
usr_hdrfiles = ["net/rime/rime.h","net/queuebuf.h","net/mac/nullmac.h","net/ip/uip.h","net/ip/tcpip.h",
                "net/packetbuf.h","net/netstack.h","sys/ctimer.h","sys/rtimer.h","sys/clock.h","lib/random.h"]
std_hdrfiles = ["string.h","stdio.h"]
stringline8 = "#include "+'"'
stringline81 = "#include "+'<'

Ret_textinputs = []
Custom_textinputs = []
FunDef_textinputs = []
VarDef_textinputs = []
MacroDef_textinputs = []
Driver_textinputs = []
Header_textinputs = []
usrhdrfiles_list = []
stdhdrfiles_list = []
headers_text = []
macros_text = []
hdrfiles = []
Driver_name_list = []
##variables_text = []
##variable_list = []

Nodeid_map = {}

MODE_NOOP = 1
MODE_EDGE_DRAG = 2
EDGE_DRAG_START_THRESHOLD = 10
DEBUG = False
Node_ID = 0
flag = 0

class Textbox(QDialog):
    def __init__(self,item_node):
        super().__init__()
        self.item_node = item_node
        self.title = "Enter your custom code here:"
        self.customnode_list = []

        custom_label1 = QLabel()
        custom_label1.setText('Custom Node Return Type:')
        custom_label1.setStyleSheet('font: 14px;')

        self.customedit1 = QLineEdit()

        custom_layout1 = QHBoxLayout()
        custom_layout1.addWidget(custom_label1)
        custom_layout1.addWidget(self.customedit1)

        custom_label2 = QLabel()
        custom_label2.setText('Custom Node Name:')
        custom_label2.setStyleSheet('font: 14px;')

        self.customedit2 = QLineEdit()

        custom_layout2 = QHBoxLayout()
        custom_layout2.addWidget(custom_label2)
        custom_layout2.addWidget(self.customedit2)

        custom_label3 = QLabel()
        custom_label3.setText('Custom Node Argument List(optional):')
        custom_label3.setStyleSheet('font: 14px;')

        self.customedit3 = QLineEdit()

        custom_layout3 = QHBoxLayout()
        custom_layout3.addWidget(custom_label3)
        custom_layout3.addWidget(self.customedit3)

        custom_label4 = QLabel()
        custom_label4.setText('Custom code:')
        custom_label4.setStyleSheet('font: 14px;')

        self.customedit4 = QTextEdit()
        self.customedit4.setAcceptRichText(True)
        
        custom_layout4 = QVBoxLayout()
        custom_layout4.addWidget(custom_label4)
        custom_layout4.addWidget(self.customedit4)

        self.addcustom = QPushButton('Add Custom Code')
        self.addcustom.clicked.connect(self.addcustomcode)

        custom_layout5 = QVBoxLayout()
        custom_layout5.addLayout(custom_layout1)
        custom_layout5.addLayout(custom_layout2)
        custom_layout5.addLayout(custom_layout3)
        custom_layout5.addLayout(custom_layout4)
        custom_layout5.addWidget(self.addcustom)

        custom_label5 = QLabel()
        custom_label5.setText('Custom Code Preview:')
        custom_label5.setStyleSheet('font: 14px;')
        
        self.customedit5 = QTextEdit()
        self.customedit5.setAcceptRichText(True)

        custom_layout6 = QVBoxLayout()
        custom_layout6.addWidget(custom_label5)
        custom_layout6.addWidget(self.customedit5)

        custom_layout7 = QHBoxLayout()
        custom_layout7.addLayout(custom_layout5)
        custom_layout7.addLayout(custom_layout6)
    
        self.okcustom = QPushButton('OK')
        self.okcustom.clicked.connect(self.savecustomcode)

        custom_layout8 = QVBoxLayout()
        custom_layout8.addLayout(custom_layout7)
        custom_layout8.addWidget(self.okcustom)

        self.setLayout(custom_layout8)
        self.setWindowTitle(self.title)
        
        if len(Custom_textinputs) != 0:
            for a in range (len(Custom_textinputs)):
                if Custom_textinputs[a][0] == self.item_node:
                    self.customedit5.append(Custom_textinputs[a][1])
                    break
##                temp = Custom_textinputs[len(Custom_textinputs)-1-a]
##                if self.item_node == temp[0]:
##                    display_text = temp[1]
##                    self.customedit5.append(display_text)
##                    break
                else:
                    continue

    
    def addcustomcode(self):
        self.custom_retype = self.customedit1.text()
        self.custom_name = self.customedit2.text()
        self.custom_arglist = self.customedit3.text()
        self.texteditvalue = self.customedit4.document().toPlainText()
        if not self.custom_arglist:
            self.customnode_text = self.custom_retype + ' ' + self.custom_name + '()\n{\n' + self.texteditvalue + '\n}'
        else:
            self.customnode_text = self.custom_retype + ' ' + self.custom_name + '(' + self.custom_arglist + ')\n{\n' + self.texteditvalue + '\n}'

        if self.customnode_text not in self.customnode_list:
            self.customnode_list.append(self.customnode_text)
            self.customedit5.append(self.customnode_text)
##            for i in range (len(self.customnode_list)):
##                self.customedit5.append(self.customnode_list[i])
            
        self.customedit1.clear()
        self.customedit2.clear()
        self.customedit3.clear()
        self.customedit4.clear()


    def savecustomcode(self):
        self.custom_code = self.customedit5.document().toPlainText()
##        print('\n\nself.texteditvalue:\n',self.custom_code)
        for key,val in Attributes.items():
            for attr,values in val.items():
                Attributes[self.item_node]['contents'] = self.custom_code
        if (len(Custom_textinputs)) != 0:
            for i in range (len(Custom_textinputs)):
                custom_id = Custom_textinputs[i]
                if custom_id[0] == self.item_node:
                    del Custom_textinputs[i]
                    Custom_textinputs.append((self.item_node,self.custom_code))
                    break
                else:
                    if i == (len(Custom_textinputs)-1):
                        Custom_textinputs.append((self.item_node,self.custom_code))
        else:
            Custom_textinputs.append((self.item_node,self.custom_code))

        self.close()

        
class Headerlist(QMainWindow):
    def __init__(self,hdrnode_id):
        super().__init__()
        self.hdrnode_id = hdrnode_id
##        self.headers_text = headers_text
        self.hdrwndw = QFrame()
        label_a = QLabel()
        label_a.setText('User-defined Files')
        label_a.setStyleSheet('font: 14px;')
        label_b = QLabel()
        label_b.setText('Standard Files')
        label_b.setStyleSheet('font: 14px;')

        self.lista = QListWidget()
        for i in range (11): self.lista.addItem(usr_hdrfiles[i])
        self.lista.setSelectionMode(QListWidget.MultiSelection)
        self.lista.clicked.connect(self.listboxa_clicked)

        self.listb = QListWidget()
        for i in range (2): self.listb.addItem(std_hdrfiles[i])
        self.listb.setSelectionMode(QListWidget.MultiSelection)
        self.listb.clicked.connect(self.listboxb_clicked)

        self.texthdr = QTextEdit()
        self.texthdr.setAcceptRichText(True)
        label_texthdr = QLabel()
        label_texthdr.setText('Macros:')
        label_texthdr.setStyleSheet('font: 14px;')

        self.button1 = QPushButton('OK', self)
        self.button1.move(30,30)
        self.button1.clicked.connect(self.saveheaders)

        layout_hdr = QHBoxLayout()
        lay1 = QVBoxLayout()
        lay1.addWidget(label_a)
        lay1.addWidget(self.lista)
        lay2 = QVBoxLayout()
        lay2.addWidget(label_b)
        lay2.addWidget(self.listb)
        lay3 = QVBoxLayout()
        lay3.addWidget(label_texthdr)
        lay3.addWidget(self.texthdr)
        layout_hdr.addLayout(lay1)
        layout_hdr.addLayout(lay2)
        layout_hdr.addLayout(lay3)
        lay4 = QVBoxLayout()
        lay4.addLayout(layout_hdr)
        lay4.addWidget(self.button1)

        self.hdrwndw.setLayout(lay4)
        self.hdrwndw.setWindowTitle("Select the header files")
        self.hdrwndw.show()
        if (len(Header_textinputs)) != 0:
            self.texthdr.append(Header_textinputs[0][1])

    def listboxa_clicked(self):
        item = self.lista.currentItem()
##        usrhdrfiles_list.append(str(item.text()))
        if (str(item.text())) in usrhdrfiles_list:
            pass
        else:
            usrhdrfiles_list.append(str(item.text()))
            headerline = stringline8 + usrhdrfiles_list[-1] + '"'
            hdrfiles.append(str(item.text()))
            self.texthdr.append(headerline)

    def listboxb_clicked(self):
        item = self.listb.currentItem()
##        stdhdrfiles_list.append(str(item.text()))
        if (str(item.text())) in stdhdrfiles_list:
            pass
        else:
            stdhdrfiles_list.append(str(item.text()))
            headerline = stringline81 + stdhdrfiles_list[m] + '>'
            hdrfiles.append(str(item.text()))
            self.texthdr.append(headerline)

    def saveheaders(self):
        
##        for k in range (len(usrhdrfiles_list)):
##            headerline = stringline8 + usrhdrfiles_list[k] + '"'
##            self.headers_text.append("\n"+headerline)
##        for m in range (len(stdhdrfiles_list)):
##            headerline = stringline81 + stdhdrfiles_list[m] + '>'
##            self.headers_text.append("\n"+headerline)

##        hdrfiles = list(set(hdrfiles))
##        print('\n hdrfiles: ',hdrfiles)

        self.texteditvalue = self.texthdr.document().toPlainText()

        for key,val in Attributes.items():
            for attr,values in val.items():
                Attributes[self.hdrnode_id]['contents'] = self.texteditvalue

        if (len(Header_textinputs)) != 0:
            del Header_textinputs[-1]
            Header_textinputs.append((self.hdrnode_id,self.texteditvalue))
        else:
            Header_textinputs.append((self.hdrnode_id,self.texteditvalue))
               
        print('\nHeader_textinputs: \n',Header_textinputs)
##        headers_text = self.headers_text
        self.hdrwndw.close()
            
class Macro_Form(QDialog):
    def __init__(self,item_id):
        super().__init__()
        self.item_id = item_id
        self.macros_text = macros_text

        self.edit = QLineEdit('Enter Macro Names:')
        self.edit.selectAll()
        
        self.edit1 = QLineEdit('Enter Macro Values:')
        self.edit1.selectAll()

        self.textmacro = QTextEdit()
        self.textmacro.setAcceptRichText(True)
        label_macrolist = QLabel()
        label_macrolist.setText('Macros:')
        label_macrolist.setStyleSheet('font: 16px;')
        
        self.layout1 = QHBoxLayout()
        self.layout1.addWidget(self.edit)
        self.layout1.addWidget(self.edit1)
        
        self.ml_layout = QVBoxLayout()
        self.ml_layout.addWidget(label_macrolist)
        self.ml_layout.addWidget(self.textmacro)
        self.ml_layout.addLayout(self.layout1)

        self.pushbutton = QPushButton('Add Macro')
        self.pushbutton.clicked.connect(self.getmacros)
        self.pushbutton1 = QPushButton('OK')
        self.pushbutton1.clicked.connect(self.closeEvent)
        self.ml_layout.addWidget(self.pushbutton)
        self.ml_layout.addWidget(self.pushbutton1)
      
        self.setLayout(self.ml_layout)
        self.setWindowTitle("Enter the Macros:")
        
        if (len(MacroDef_textinputs)) != 0:
            self.textmacro.append(MacroDef_textinputs[0][1])

    def getmacros(self):
        self.macroname = self.edit.text()
        self.macrovalue = self.edit1.text()
        if self.macroname != 'Enter Macro Names:' and self.macrovalue != 'Enter Macro Values:':
            if ('#define '+self.macroname+' '+self.macrovalue) not in self.macros_text:
                self.macros_text.append(('#define '+self.macroname+' '+self.macrovalue))
                self.textmacro.append(self.macros_text[-1])

        self.edit.clear()
        self.edit1.clear()
  
    def debugmacro_code(self):
        debugmacroline1 = '\n#if DEBUG'
        debugmacroline2 = '\n#include <stdio.h>'
        debugmacroline3 = '\n#define PRINTF(...) printf(__VA_ARGS__)'
        debugmacroline4 = '\n#else /* DEBUG */'
        debugmacroline5 = '\n#define PRINTF(...)'
        debugmacroline6 = '\n#endif /* DEBUG */'
        debugmacroline = debugmacroline1 + debugmacroline2 + debugmacroline3 + debugmacroline4 + debugmacroline5 + debugmacroline6
        if debugmacroline not in self.macros_text:
            self.macros_text.append(debugmacroline)
            self.textmacro.append(debugmacroline)

    def closeEvent(self, event):
        
        if (len(MacroDef_textinputs)) == 0:
            self.debugmacro_code()

        self.texteditvalue = self.textmacro.document().toPlainText()
        for key,val in Attributes.items():
            for attr,values in val.items():
                Attributes[self.item_id]['contents'] = self.texteditvalue

        if (len(MacroDef_textinputs)) != 0:
            del MacroDef_textinputs[-1]
            MacroDef_textinputs.append((self.item_id,self.texteditvalue))
        else:
            MacroDef_textinputs.append((self.item_id,self.texteditvalue))

        self.close()
        

class Variable_Form(QDialog):
    def __init__(self,item_id):
        super().__init__()
        self.item_id = item_id
        self.variable_list = []
        
        var_label1 = QLabel()
        var_label1.setText('Variable Type:')
        var_label1.setStyleSheet('font: 14px;')

        var_label2 = QLabel()
        var_label2.setText('Variable Name:')
        var_label2.setStyleSheet('font: 14px;')

        var_label3 = QLabel()
        var_label3.setText('Variable Value (optional):')
        var_label3.setStyleSheet('font: 14px;')
        
        self.edit1 = QLineEdit()
        self.edit2 = QLineEdit()
        self.edit3 = QLineEdit()

        self.btn1 = QPushButton('Add Variable')
        self.btn1.clicked.connect(self.addvariables)
        self.btn2 = QPushButton('OK')
        self.btn2.clicked.connect(self.savevariables)

        self.textvar = QTextEdit()
        self.textvar.setAcceptRichText(True)
        label_variable= QLabel()
        label_variable.setText('Variables:')
        label_variable.setStyleSheet('font: 15px;')

        self.v_layout = QVBoxLayout()
        self.v_layout.addWidget(label_variable)
        self.v_layout.addWidget(self.textvar)
        
        self.L1 = QHBoxLayout()
        self.L1.addWidget(var_label1)
        self.L1.addWidget(self.edit1)

        self.L2 = QHBoxLayout()
        self.L2.addWidget(var_label2)
        self.L2.addWidget(self.edit2)

        self.L3 = QHBoxLayout()
        self.L3.addWidget(var_label3)
        self.L3.addWidget(self.edit3)

        self.Lay = QVBoxLayout()
        self.Lay.addLayout(self.L1)
        self.Lay.addLayout(self.L2)
        self.Lay.addLayout(self.L3)
        self.Lay.addWidget(self.btn1)
        self.Lay.addWidget(self.btn2)

        self.L4 = QHBoxLayout()
        self.L4.addLayout(self.Lay)
        self.L4.addLayout(self.v_layout)

        self.setLayout(self.L4)
        self.setWindowTitle("Enter the Variables:")

        if (len(VarDef_textinputs)) != 0:
            self.textvar.append(VarDef_textinputs[0][1])

    def addvariables(self):
        self.var_type = self.edit1.text()
        self.var_name = self.edit2.text()
        self.var_val = self.edit3.text()
        if not self.var_val : self.variable_text = self.var_type+' '+self.var_name+';'
        if self.var_val: self.variable_text = self.var_type+' '+self.var_name+' = '+self.var_val+';'
        
        if self.var_type and self.var_name:
            if self.variable_text not in self.variable_list:
                self.variable_list.append(self.variable_text)
                self.textvar.append(self.variable_text)
        self.edit1.clear()
        self.edit2.clear()
        self.edit3.clear()

    def savevariables(self):
        self.texteditvalue = self.textvar.document().toPlainText()
        for key,val in Attributes.items():
            for attr,values in val.items():
                Attributes[self.item_id]['contents'] = self.texteditvalue
        if (len(VarDef_textinputs)) != 0:
            del VarDef_textinputs[-1]
            VarDef_textinputs.append((self.item_id,self.texteditvalue))
        else:
            VarDef_textinputs.append((self.item_id,self.texteditvalue))
##        print('\nVarDef_textinputs:\n',VarDef_textinputs)
        self.close()

class Function_wndw(QDialog):
    def __init__(self,itemid):
        super().__init__()
        self.itemid = itemid
        self.function_list = []
        
        fun_label1 = QLabel()
        fun_label1.setText('Function Return Type:')
        fun_label1.setStyleSheet('font: 14px;')

        fun_label2 = QLabel()
        fun_label2.setText('Function Name:')
        fun_label2.setStyleSheet('font: 14px;')

        fun_label3 = QLabel()
        fun_label3.setText('Function Argument List(optional):')
        fun_label3.setStyleSheet('font: 14px;')

        fun_label4 = QLabel()
        fun_label4.setText('Function code:')
        fun_label4.setStyleSheet('font: 14px;')

        self.funedit1 = QLineEdit()
        self.funedit2 = QLineEdit()
        self.funedit3 = QLineEdit()
        
        self.funedit4 = QTextEdit()
        self.funedit4.setAcceptRichText(True)

        fun_label5 = QLabel()
        fun_label5.setText('Function preview:')
        fun_label5.setStyleSheet('font: 14px;')
        self.funedit5 = QTextEdit()
        self.funedit5.setAcceptRichText(True)

        self.addfunbutton = QPushButton('Add Function')
        self.addfunbutton.clicked.connect(self.addfunction)
        self.funbutton = QPushButton('OK')
        self.funbutton.clicked.connect(self.savefunction)

        fun_layout1 = QHBoxLayout()
        fun_layout1.addWidget(fun_label1)
        fun_layout1.addWidget(self.funedit1)

        fun_layout2 = QHBoxLayout()
        fun_layout2.addWidget(fun_label2)
        fun_layout2.addWidget(self.funedit2)

        fun_layout3 = QHBoxLayout()
        fun_layout3.addWidget(fun_label3)
        fun_layout3.addWidget(self.funedit3)
        
        fun_layout4 = QHBoxLayout()
        fun_layout4.addWidget(fun_label4)
        fun_layout4.addWidget(self.funedit4)

        fun_layout41 = QVBoxLayout()
        fun_layout41.addWidget(fun_label5)
        fun_layout41.addWidget(self.funedit5)
        
        fun_layout5 = QVBoxLayout()
        fun_layout5.addLayout(fun_layout1)
        fun_layout5.addLayout(fun_layout2)
        fun_layout5.addLayout(fun_layout3)
        fun_layout5.addLayout(fun_layout4)
        fun_layout5.addWidget(self.addfunbutton)

        fun_layout6 = QHBoxLayout()
        fun_layout6.addLayout(fun_layout5)
        fun_layout6.addLayout(fun_layout41)

        fun_layout7 = QVBoxLayout()
        fun_layout7.addLayout(fun_layout6)
        fun_layout7.addWidget(self.funbutton)

        self.setLayout(fun_layout7)
        self.setWindowTitle("Enter the function parameters:")

        if (len(FunDef_textinputs)) != 0:
            self.funedit5.append(FunDef_textinputs[0][1])


    def addfunction(self):
##        print("add function...")
        self.fun_retype = self.funedit1.text()
        self.fun_name = self.funedit2.text()
        self.fun_arglist = self.funedit3.text()
        self.texteditvalue = self.funedit4.document().toPlainText()
        if not self.fun_arglist:
            self.fundef_text = self.fun_retype + ' ' + self.fun_name + '()\n{\n' + self.texteditvalue + '\n}'
        else:
            self.fundef_text = self.fun_retype + ' ' + self.fun_name + '(' + self.fun_arglist + ')\n{\n' + self.texteditvalue + '\n}'

        if self.fun_retype and self.fun_name:
            if self.fundef_text not in self.function_list:
                self.function_list.append(self.fundef_text)
                self.funedit5.append(self.fundef_text)
        self.funedit1.clear()
        self.funedit2.clear()
        self.funedit3.clear()
        self.funedit4.clear()
        
    def savefunction(self):
##        print("save function...")
        self.texteditvalue = self.funedit5.document().toPlainText()
        for key,val in Attributes.items():
            for attr,values in val.items():
                Attributes[self.itemid]['contents'] = self.texteditvalue
        if (len(FunDef_textinputs)) != 0:
            del FunDef_textinputs[-1]
            FunDef_textinputs.append((self.itemid,self.texteditvalue))
        else:
            FunDef_textinputs.append((self.itemid,self.texteditvalue))

        self.close()

class Driver_function(QDialog):
    def __init__(self,itemid):
        super().__init__()
        self.itemid = itemid
        self.driverfn_list = []

        drvrfn_label1 = QLabel()
        drvrfn_label1.setText('Driver function Return Type:')
        drvrfn_label1.setStyleSheet('font: 14px;')

        drvrfn_label2 = QLabel()
        drvrfn_label2.setText('Driver function Name:')
        drvrfn_label2.setStyleSheet('font: 14px;')

        drvrfn_label3 = QLabel()
        drvrfn_label3.setText('Driver function Contents:')
        drvrfn_label3.setStyleSheet('font: 14px;')

        self.drvredit1 = QLineEdit()
        self.drvredit2 = QLineEdit()
        self.drvredit3 = QTextEdit()
        self.drvredit3.setAcceptRichText(True)

        drvr_layout1 = QHBoxLayout()
        drvr_layout1.addWidget(drvrfn_label1)
        drvr_layout1.addWidget(self.drvredit1)

        drvr_layout2 = QHBoxLayout()
        drvr_layout2.addWidget(drvrfn_label2)
        drvr_layout2.addWidget(self.drvredit2)

        drvr_layout3 = QHBoxLayout()
        drvr_layout3.addWidget(drvrfn_label3)
        drvr_layout3.addWidget(self.drvredit3)

        self.add_drvbutton = QPushButton('Add Driver Function')
        self.add_drvbutton.clicked.connect(self.add_drvfunction)

        self.layout4 = QVBoxLayout()
        self.layout4.addLayout(drvr_layout1)
        self.layout4.addLayout(drvr_layout2)
        self.layout4.addLayout(drvr_layout3)
        self.layout4.addWidget(self.add_drvbutton)

        drvrfn_label4 = QLabel()
        drvrfn_label4.setText('Driver Function preview:')
        drvrfn_label4.setStyleSheet('font: 14px;')
        self.drvredit4 = QTextEdit()
        self.drvredit4.setAcceptRichText(True)

        self.layout5 = QVBoxLayout()
        self.layout5.addWidget(drvrfn_label4)
        self.layout5.addWidget(self.drvredit4)

        self.drvrbutton = QPushButton('OK')
        self.drvrbutton.clicked.connect(self.save_drvfunction)

        self.layout6 = QHBoxLayout()
        self.layout6.addLayout(self.layout4)
        self.layout6.addLayout(self.layout5)

        self.layout7 = QVBoxLayout()
        self.layout7.addLayout(self.layout6)
        self.layout7.addWidget(self.drvrbutton)

        self.setLayout(self.layout7)
        self.setWindowTitle("Enter the driver function parameters:")

        if (len(Driver_textinputs)) != 0:
            self.drvredit4.append(Driver_textinputs[0][1])

    def add_drvfunction(self):
        self.drv_retype = self.drvredit1.text()
        self.drv_name = self.drvredit2.text()
        self.texteditvalue = self.drvredit3.document().toPlainText()

        self.drvfun_text = self.drv_retype + ' mac_driver ' + self.drv_name + ' = {\n' + self.texteditvalue + '\n};\n'

        if self.drv_retype and self.drv_name:
            if self.drvfun_text not in self.driverfn_list:
                self.driverfn_list.append(self.drvfun_text)
                self.drvredit4.append(self.drvfun_text)

        if (len(Driver_name_list)) != 0:
            del Driver_name_list[-1]
        Driver_name_list.append(self.drv_name)

        self.drvredit1.clear()
        self.drvredit2.clear()
        self.drvredit3.clear()
##        print('\n(add)Driver_name_list : ',Driver_name_list)

    def save_drvfunction(self):
        self.texteditvalue = self.drvredit4.document().toPlainText()
        for key,val in Attributes.items():
            for attr,values in val.items():
                Attributes[self.itemid]['contents'] = self.texteditvalue
        if (len(Driver_textinputs)) != 0:
            del Driver_textinputs[-1]
            Driver_textinputs.append((self.itemid,self.texteditvalue))
        else:
            Driver_textinputs.append((self.itemid,self.texteditvalue))

        self.close()
##        print('\n(save)Driver_name_list : ',Driver_name_list)
        
class QDMGraphicsView(QGraphicsView):
    def __init__(self, grScene,scene,list_flag, parent=None):
        super().__init__(parent)
        
        self.scene = scene
        self.grScene = grScene

        self.Attributes = Attributes
        self.nodeslist = nodeslist
        self.p_nodeslist = p_nodeslist
        self.newnodes_list = newnodes_list

        self.cur_startsocket = None
        self.cur_endsocket = None
        
        self.list_flag = list_flag
        self.flag = 0
        self.st_init = 0
        self.st_sp = 0
        self.st_pi = 0
        self.st_on = 0
        self.st_off = 0
        self.st_cci = 0
        self.header = 0
        self.macro = 0
        self.variable = 0
        self.function = 0
        self.driver = 0

        self.initUI()

        self.setScene(self.grScene)

        self.mode = MODE_NOOP

        self.zoomInFactor = 1.25
        self.zoomClamp = True
        self.zoom = 10
        self.zoomStep = 1
        self.zoomRange = [0, 10]
        return 

    def initUI(self):
        self.setRenderHints(QPainter.Antialiasing | QPainter.HighQualityAntialiasing | 
                    QPainter.TextAntialiasing | QPainter.SmoothPixmapTransform)
        self.setViewportUpdateMode(QGraphicsView.FullViewportUpdate)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)

        if self.list_flag[0] == 0:
            pass
        else:
            try:
                options = QFileDialog.Options()
                options |= QFileDialog.DontUseNativeDialog
                fileName = QFileDialog.getOpenFileName(self,"Open pickle file...","","All Files (*);;pickle Files (*.gpickle)", options=options)
                G = nx.read_gpickle(fileName[0])
                self.flag = 1
                self.depickling(G)
            except IOError:
    ##            print('\npickle file NOT found\n')
                self.flag = 0

    def depickling(self,G):

        self.Dp_nodes = list(G.nodes)
        self.Dp_edges = list(G.edges)

        Attrib = nx.get_node_attributes(G,'name')
        loc = nx.get_node_attributes(G,'pos')
        cont = nx.get_node_attributes(G,'contents')
        self.cont = cont

        for i in range ((len(self.Dp_nodes))):
            self.point = loc[self.Dp_nodes[i]]
            self.position = self.point
            self.node_content = cont[self.Dp_nodes[i]]
            self.current_node = self.Dp_nodes[i]
            if Attrib[self.Dp_nodes[i]] == 'Init':
                self.list_flag[0] = 1
            if Attrib[self.Dp_nodes[i]] == 'Send_Packet':
                self.list_flag[0] = 2
            if Attrib[self.Dp_nodes[i]] == 'Packet_Input':
                self.list_flag[0] = 3
            if Attrib[self.Dp_nodes[i]] == 'On':
                self.list_flag[0] = 4
            if Attrib[self.Dp_nodes[i]] == 'Off':
                self.list_flag[0] = 5
            if Attrib[self.Dp_nodes[i]] == 'Channel_check_Interval':
                self.list_flag[0] = 6
            if Attrib[self.Dp_nodes[i]] == 'Wait for packet Node':
                self.list_flag[0] = 7
            if Attrib[self.Dp_nodes[i]] == 'Random backoff Node':
                self.list_flag[0] = 8
            if Attrib[self.Dp_nodes[i]] == 'Send packet Node':
                self.list_flag[0] = 9
            if Attrib[self.Dp_nodes[i]] == 'Return Value Node':
                self.list_flag[0] = 10
            if Attrib[self.Dp_nodes[i]] == 'Function Call Node':
                self.list_flag[0] = 11
            if Attrib[self.Dp_nodes[i]] == 'Variable Assignment Node':
                self.list_flag[0] = 12
            if Attrib[self.Dp_nodes[i]] == 'Custom Code Node':
                self.list_flag[0] = 13
            if Attrib[self.Dp_nodes[i]] == 'Function Definition Node':
                self.list_flag[0] = 14
            if Attrib[self.Dp_nodes[i]] == 'Variable Definition Node':
                self.list_flag[0] = 15
            if Attrib[self.Dp_nodes[i]] == 'Macro Definition Node':
                self.list_flag[0] = 16
            if Attrib[self.Dp_nodes[i]] == 'Driver Node':
                self.list_flag[0] = 17
            if Attrib[self.Dp_nodes[i]] == 'Header Node':
                self.list_flag[0] = 18
                
            self.create_nodes(self.position,self.list_flag)
            Nodeid_map[self.Dp_nodes[i]] = self.newnodes_list[-1]

            if self.list_flag[0] == 10:
                Ret_textinputs.append((hex(id(self.nodeslist[-1])),cont[self.Dp_nodes[i]]))
##                print('Ret_textinputs:\n',Ret_textinputs)

            if self.list_flag[0] == 13:
                Custom_textinputs.append((hex(id(self.nodeslist[-1])),cont[self.Dp_nodes[i]]))
##                print('Custom_textinputs:\n',Custom_textinputs)

            if self.list_flag[0] == 14:
                FunDef_textinputs.append((hex(id(self.nodeslist[-1])),cont[self.Dp_nodes[i]]))
##                print('FunDef_textinputs:\n',FunDef_textinputs)

            if self.list_flag[0] == 15:
                VarDef_textinputs.append((hex(id(self.nodeslist[-1])),cont[self.Dp_nodes[i]]))
##                print('VarDef_textinputs:\n',VarDef_textinputs)

            if self.list_flag[0] == 16:
                MacroDef_textinputs.append((hex(id(self.nodeslist[-1])),cont[self.Dp_nodes[i]]))
##                print('MacroDef_textinputs:\n',MacroDef_textinputs)

            if self.list_flag[0] == 17:
                Driver_textinputs.append((hex(id(self.nodeslist[-1])),cont[self.Dp_nodes[i]]))
##                print('Driver_textinputs:\n',Driver_textinputs)

            if self.list_flag[0] == 18:
                Header_textinputs.append((hex(id(self.nodeslist[-1])),cont[self.Dp_nodes[i]]))
##                print('Header_textinputs:\n',Header_textinputs)

        startsocket = nx.get_edge_attributes(G,'start_socket')
        startindices = nx.get_edge_attributes(G,'index1')
        startpositions = nx.get_edge_attributes(G,'position1')
        starttypes = nx.get_edge_attributes(G,'type1')

        endsocket  = nx.get_edge_attributes(G,'end_socket')
        endindices = nx.get_edge_attributes(G,'index2')
        endpositions = nx.get_edge_attributes(G,'position2')
        endtypes = nx.get_edge_attributes(G,'type2')

        for m in range ((len(self.Dp_edges))):
            temp = self.Dp_edges[m]
            current_node1 = Nodeid_map[temp[0]]
            current_index1 = startindices[temp]
            current_position1 = startpositions[temp]
            current_type1 = starttypes[temp]
            
            current_node2 = Nodeid_map[temp[1]]
            current_index2 = endindices[temp]
            current_position2 = endpositions[temp]
            current_type2 = endtypes[temp]
    
            for x in range (len(Node_sockets)):
                if Node_sockets[x][1]==current_node1 and Node_sockets[x][2]==current_index1 and Node_sockets[x][3]==current_position1 and Node_sockets[x][4]==current_type1:
                    self.cur_startsocket = Node_sockets[x][0]
                if Node_sockets[x][1]==current_node2 and Node_sockets[x][2]==current_index2 and Node_sockets[x][3]==current_position2 and Node_sockets[x][4]==current_type2:
                    self.cur_endsocket = Node_sockets[x][0]

            Edge(self.scene, self.cur_startsocket, self.cur_endsocket, EDGE_TYPE_BEZIER)

    def mousePressEvent(self,event):
        if event.button() == Qt.MiddleButton:
            self.middleMouseButtonPress(event)
        elif event.button() == Qt.LeftButton:
            self.leftMouseButtonPress(event)
        elif event.button() == Qt.RightButton:
            self.rightMouseButtonPress(event)
        else:
            super().mousePressEvent(event)


    def mouseReleaseEvent(self,event):
        if event.button() == Qt.MiddleButton:
            self.middleMouseButtonRelease(event)
        elif event.button() == Qt.LeftButton:
            self.leftMouseButtonRelease(event)
        elif event.button() == Qt.RightButton:
            self.rightMouseButtonRelease(event)
        else:
            super().mouseReleaseEvent(event)

    def middleMouseButtonPress(self, event):
        releaseEvent = QMouseEvent(QEvent.MouseButtonRelease, event.localPos(), event.screenPos(),
                        Qt.LeftButton, Qt.NoButton, event.modifiers())
        super().mouseReleaseEvent(releaseEvent)
        self.setDragMode(QGraphicsView.ScrollHandDrag)
        fakeEvent = QMouseEvent(event.type(), event.localPos(), event.screenPos(),
                    Qt.LeftButton, event.buttons() | Qt.LeftButton, event.modifiers())
        super().mousePressEvent(fakeEvent)

    def middleMouseButtonRelease(self,event):
        fakeEvent = QMouseEvent(event.type(), event.localPos(), event.screenPos(),
                    Qt.LeftButton, event.buttons() & -Qt.LeftButton, event.modifiers())
        super().mouseReleaseEvent(fakeEvent)
        self.setDragMode(QGraphicsView.NoDrag)
##
##    def rightMouseButtonPress(self,event):
##        item = self.getItemAtClick(event)
##        Socket.__init__(self, item, index=0, position=1,socket_type=1)
##        Edge.remove_from_sockets(self)
##        Edge.remove(self)
####        self.remove()
##
##    def rightMouseButtonRelease(self, event):
##        item = self.getItemAtClick(event)
##        super().mouseReleaseEvent(event)
##        

    def leftMouseButtonPress(self,event):
        item = self.getItemAtClick(event)

        if type(item) is QDMGraphicsNode:
            self.pos = self.mapToScene(event.pos())
            for key,val in self.Attributes.items():
                for attr,values in val.items():
                    self.Attributes[hex(id(item))]['pos'] = self.pos

        if item is None:
            p = self.mapToScene(event.pos())
            self.create_nodes(p,self.list_flag)

        self.last_lmb_click_scene_pos = self.mapToScene(event.pos())

        if type(item) is QDMGraphicsSocket:
            if self.mode == MODE_NOOP:
                self.mode = MODE_EDGE_DRAG
                self.edgeDragStart(item)
                return

        if self.mode == MODE_EDGE_DRAG:
            res = self.edgeDragEnd(item)
            if res: return

        super().mousePressEvent(event)

    def leftMouseButtonRelease(self, event):
        item = self.getItemAtClick(event)

        if self.mode == MODE_EDGE_DRAG:
            if self.distanceBetweenClickAndReleaseIsOff(event):
                res = self.edgeDragEnd(item)
                if res: return

        super().mouseReleaseEvent(event)

    
    def mouseDoubleClickEvent(self, event):
        item = self.getItemAtClick(event)
##        print('\n\nVarDef_textinputs:\n',VarDef_textinputs)
##        print('\n\nMacroDef_textinputs:\n',MacroDef_textinputs)
##        print('\n\nHeader_textinputs:\n',Header_textinputs)
        if type(item) is QDMGraphicsNode:
            if (hex(id(item))) in Rv_node:
                if (len(Ret_textinputs)) > 0:
                    for k in range (len(Ret_textinputs)):
                        tmp = Ret_textinputs[k]
                        if tmp[0] == (hex(id(item))):
                            Ret_textinputs.remove(Ret_textinputs[k])
                            text,okPressed = QInputDialog.getText(self, "Return Value ?","Enter the return value:", QLineEdit.Normal, tmp[1])
                            if okPressed and text != '':
                                Ret_textinputs.append((hex(id(item)),text))
                                for key,val in self.Attributes.items():
                                    for attr,values in val.items():
                                        self.Attributes[hex(id(item))]['contents'] = text
                                break
                        else:
                            if k == (len(Ret_textinputs)-1):
                                text, okPressed = QInputDialog.getText(self, "Return Value ?","Enter the return value:", QLineEdit.Normal, "")
                                if okPressed and text != '':
                                    Ret_textinputs.append((hex(id(item)),text))
                                    for key,val in self.Attributes.items():
                                        for attr,values in val.items():
                                            self.Attributes[hex(id(item))]['contents'] = text
                            continue
                else:
                    text, okPressed = QInputDialog.getText(self, "Return Value ?","Enter the return value:", QLineEdit.Normal, "")
                    if okPressed and text != '':
                        for t in range (len(Ret_textinputs)):
                            temp = Ret_textinputs[t]
                            if (hex(id(item))) == temp[0]:
                                Ret_textinputs.remove(Ret_textinputs[t])
                                break
                            else:
                                continue
                        Ret_textinputs.append((hex(id(item)),text))
                        for key,val in self.Attributes.items():
                            for attr,values in val.items():
                                self.Attributes[hex(id(item))]['contents'] = text

            if (hex(id(item))) in Cust_node:
                self.display_textbox = Textbox(hex(id(item)))
                self.display_textbox.show()

            if (hex(id(item))) in FunDef_node:
                self.display_function = Function_wndw(hex(id(item)))
                self.display_function.show()

            if (hex(id(item))) in VarDef_node:
                self.variable_form = Variable_Form(hex(id(item)))
                self.variable_form.show()

            if (hex(id(item))) in MacroDef_node:
                self.inputdialogs = Macro_Form(hex(id(item)))
                self.inputdialogs.show()
##                self.display_textbox = Textbox(hex(id(item)))
##                self.display_textbox.show()

            if (hex(id(item))) in Driver_node:
                self.display_driver = Driver_function(hex(id(item)))
                self.display_driver.show()

            if (hex(id(item))) in Header_node:
                self.display_headerlist = Headerlist(hex(id(item)))
##                self.display_headerlist.show()
                

    def mouseMoveEvent(self, event):
        item = self.getItemAtClick(event)
        
        if self.mode == MODE_EDGE_DRAG:
            pos = self.mapToScene(event.pos())
            self.dragEdge.grEdge.setDestination(pos.x(), pos.y())
            self.dragEdge.grEdge.update()

        super().mouseMoveEvent(event)
  
    def getItemAtClick(self, event):
        """ return the object on which we've clicked/release mouse button """
        pos = event.pos()
        obj = self.itemAt(pos)
        return obj

    def edgeDragStart(self, item):
        if DEBUG: print('View::edgeDragStart ~ Start dragging edge')
        if DEBUG: print('View::edgeDragStart ~   assign Start Socket')
        if DEBUG: print('View::edgeDragStart ~   assign Start Socket to:', item.socket)
        self.previousEdge = item.socket.edge
        self.last_start_socket = item.socket
        self.dragEdge = Edge(self.grScene.scene, item.socket, None, EDGE_TYPE_BEZIER)
        if DEBUG: print('View::edgeDragStart ~   dragEdge:', self.dragEdge)

    def edgeDragEnd(self, item):
        """ return True if skip the rest of the code """
        self.mode = MODE_NOOP
        if type(item) is QDMGraphicsSocket:
            if DEBUG: print('View::edgeDragEnd ~   previous edge:', self.previousEdge)
            if item.socket.hasEdge():
                item.socket.edge.remove()
            if DEBUG: print('View::edgeDragEnd ~   assign End Socket', item.socket)
            if self.previousEdge is not None: self.previousEdge.remove()
            if DEBUG: print('View::edgeDragEnd ~  previous edge removed')
            self.dragEdge.start_socket = self.last_start_socket
            self.dragEdge.end_socket = item.socket
            self.dragEdge.start_socket.setConnectedEdge(self.dragEdge)
            self.dragEdge.end_socket.setConnectedEdge(self.dragEdge)
            
            if DEBUG: print('View::edgeDragEnd ~  reassigned start & end sockets to drag edge')
            self.dragEdge.updatePositions()
            return True

        if DEBUG: print('View::edgeDragEnd ~ End dragging edge')
        self.dragEdge.remove()
        self.dragEdge = None
        if DEBUG: print('View::edgeDragEnd ~ about to set socket to previous edge:', self.previousEdge)
        if self.previousEdge is not None:
            self.previousEdge.start_socket.edge = self.previousEdge
        if DEBUG: print('View::edgeDragEnd ~ everything done.')
        return False

    def distanceBetweenClickAndReleaseIsOff(self, event):
        """ measures if we are too far from the last LMB click scene position """
        new_lmb_release_scene_pos = self.mapToScene(event.pos())
        dist_scene = new_lmb_release_scene_pos - self.last_lmb_click_scene_pos
        edge_drag_threshold_sq = EDGE_DRAG_START_THRESHOLD*EDGE_DRAG_START_THRESHOLD
        return (dist_scene.x()*dist_scene.x() + dist_scene.y()*dist_scene.y()) > edge_drag_threshold_sq

    def wheelEvent(self,event):
        zoomOutFactor = 1/self.zoomInFactor

        if event.angleDelta().y() > 0:
            zoomFactor = self.zoomInFactor
            self.zoom += self.zoomStep
        else:
            zoomFactor = zoomOutFactor
            self.zoom -= self.zoomStep

        clamped = False
        if (self.zoom < self.zoomRange[0]):
            self.zoom, clamped = self.zoomRange[0], True
        if (self.zoom > self.zoomRange[1]):
            self.zoom, clamped = self.zoomRange[1], True

        if not clamped or self.zoomClamp is False:
            self.scale(zoomFactor, zoomFactor)

    def create_nodes(self,point,list_flag):
        self.point = point
##        if self.flag == 1: self.point = self.position
        self.list_flag = list_flag

        if self.list_flag[0] == 1:
            self.st_init += 1
            self.node_content = INIT_content1+INIT_content2
            if self.st_init > 1:
                QMessageBox.about(self, "Init node !", "Only one Init node can be created !")
            else:
                node_st = Start_Node_Init(self.node_content,self.point,self.scene,"Init",inputs=[],outputs=[1])
                node_st.setPos(self.point.x(),self.point.y())
    
                
        if self.list_flag[0] == 2:
            self.st_sp += 1
            self.node_content = SP_content1+SP_content_custom+SP_content2
            if self.st_sp > 1:
                QMessageBox.about(self, "Send_Packet node !", "Only one Send_Packet node can be created !")
            else:
                node_st = Start_Node_SP(self.node_content,self.point,self.scene,"Send_Packet",inputs=[],outputs=[1])
                node_st.setPos(self.point.x(),self.point.y())
                
        if self.list_flag[0] == 3:
            self.st_pi += 1
            self.node_content = PI_content1+PI_content_custom+PI_content2
            if self.st_pi > 1:
                QMessageBox.about(self, "Packet_Input node !", "Only one Packet_Input node can be created !")
            else:
                node_st = Start_Node_PI(self.node_content,self.point,self.scene,"Packet_Input",inputs=[],outputs=[1])
                node_st.setPos(self.point.x(),self.point.y())

                
        if self.list_flag[0] == 4:
            self.st_on += 1
            self.node_content = ON_content1 + ON_content2
            if self.st_on > 1:
                QMessageBox.about(self, "ON node !", "Only one ON node can be created !")
            else:
                node_st = Start_Node_On(self.node_content,self.point,self.scene,"ON",inputs=[],outputs=[1])
                node_st.setPos(self.point.x(),self.point.y())

                
        if self.list_flag[0] == 5:
            self.st_off += 1
            self.node_content = OFF_content1 + OFF_content2
            if self.st_off > 1:
                QMessageBox.about(self, "OFF node !", "Only one OFF node can be created !")
            else:
                node_st = Start_Node_Off(self.node_content,self.point,self.scene,"OFF",inputs=[],outputs=[1])
                node_st.setPos(self.point.x(),self.point.y())

                
        if self.list_flag[0] == 6:
            self.st_cci += 1
            self.node_content = CCI_content1 + CCI_content2
            if self.st_cci > 1:
                QMessageBox.about(self, "Channel_Check_Interval node !", "Only one channel_check_interval node can be created !")
            else:
                node_st = Start_Node_CCI(self.node_content,self.point,self.scene,"Channel_Check_Interval",inputs=[],outputs=[1])
                node_st.setPos(self.point.x(),self.point.y())

            
        if self.list_flag[0] == 7:
            self.node_content = "Wait for Packet Node"
            node_wfp = Waitforpkt_Node(self.node_content,self.point,self.scene,"WaitforPacketNode",inputs=[1],outputs=[1])
            node_wfp.setPos(self.point.x(),self.point.y())


        if self.list_flag[0] == 8:
            self.node_content = "Random Backoff Node"
            node_rb = Randombackoff_Node(self.node_content,self.point,self.scene,"RandomBackoffNode",inputs=[1,2],outputs=[1])
            node_rb.setPos(self.point.x(),self.point.y())


        if self.list_flag[0] == 9:
            self.node_content = "Send Packet Node"
            node_sp = Sendpacket_Node(self.node_content,self.point,self.scene,"SendPacketNode",inputs=[1,2,3],outputs=[1])
            node_sp.setPos(self.point.x(),self.point.y())


        if self.list_flag[0] == 10:
##            self.node_content = "Return Value Node"
            node_return = ReturnValue_Node(self.node_content,self.point,self.scene,"ReturnValueNode",inputs=[1],outputs=[])
            node_return.setPos(self.point.x(),self.point.y())


        if self.list_flag[0] == 11:
##            self.node_content = "Fuction Call Node"
            node_funcall = FunctionCall_Node(self.node_content,self.point,self.scene,"FunctionCallNode",inputs=[1],outputs=[1])
            node_funcall.setPos(self.point.x(),self.point.y())


        if self.list_flag[0] == 12:
##            self.node_content = "Variable Assignment Node"
            node_varass = VariableAssign_Node(self.node_content,self.point,self.scene,"VariableAssignmentNode",inputs=[1],outputs=[1])
            node_varass.setPos(self.point.x(),self.point.y())


        if self.list_flag[0] == 13:
##            self.node_content = "Custom Code Node"
            node_custom = CustomCode_Node(self.node_content,self.point,self.scene,"CustomCodeNode",inputs=[1],outputs=[1])
            node_custom.setPos(self.point.x(),self.point.y())


        if self.list_flag[0] == 14:
            node_fundef = FunctionDefinition_Node(self.node_content,self.point,self.scene,"FunctionDefinitionNode",inputs=[],outputs=[])
            node_fundef.setPos(self.point.x(),self.point.y())
##            self.node_content = "Function Definition Node"
##            if self.function >= 1:
##                QMessageBox.about(self, "One Function Definition Node is enough!", "Edit the already created Function Definition node!")
##            else:
##                node_fundef = FunctionDefinition_Node(self.node_content,self.point,self.scene,"FunctionDefinitionNode",inputs=[],outputs=[])
##                node_fundef.setPos(self.point.x(),self.point.y())
##                self.function += 1


        if self.list_flag[0] == 15:
            node_vardef = VariableDefinition_Node(self.node_content,self.point,self.scene,"VariableDefinitionNode",inputs=[],outputs=[])
            node_vardef.setPos(self.point.x(),self.point.y())
##            self.node_content = "Variable Definition Node"
##            if self.variable >= 1:
##                QMessageBox.about(self, "One Variable Definition Node is enough!", "Edit the already created Variable Definition node!")
##            else:
##                node_vardef = VariableDefinition_Node(self.node_content,self.point,self.scene,"VariableDefinitionNode",inputs=[],outputs=[])
##                node_vardef.setPos(self.point.x(),self.point.y())
##                self.variable += 1

        if self.list_flag[0] == 16:
            node_macrodef = MacroDefinition_Node(self.node_content,self.point,self.scene,"MacroDefinitionNode",inputs=[],outputs=[])
            node_macrodef.setPos(self.point.x(),self.point.y())
##            self.node_content = "Macro Definition Node"
##            if self.macro >= 1:
##                QMessageBox.about(self, "One Macro Definition Node is enough!", "Edit the already created Macro Definition node!")
##            else:
##                node_macrodef = MacroDefinition_Node(self.node_content,self.point,self.scene,"MacroDefinitionNode",inputs=[],outputs=[])
##                node_macrodef.setPos(self.point.x(),self.point.y())
##                self.macro += 1

        if self.list_flag[0] == 17:
            node_driver = Driver_Node(self.node_content,self.point,self.scene,"DriverNode",inputs=[],outputs=[])
            node_driver.setPos(self.point.x(),self.point.y())
            
##            self.node_content = "Driver Node"
##            if self.driver >= 1:
##                QMessageBox.about(self, "One Driver Node is enough!", "Edit the already created Driver node!")
##            else:
##                node_driver = Driver_Node(self.node_content,self.point,self.scene,"DriverNode",inputs=[],outputs=[])
##                node_driver.setPos(self.point.x(),self.point.y())
##                self.driver += 1

        if self.list_flag[0] == 18:
            node_header = Header_Node(self.node_content,self.point,self.scene,"HeaderNode",inputs=[],outputs=[])
            node_header.setPos(self.point.x(),self.point.y())
##            self.node_content = "Header Node"
##            if self.header >= 1:
##                QMessageBox.about(self, "One Header Node is enough!", "Edit the already created Header node!")
##            else:
##                node_header = Header_Node(self.node_content,self.point,self.scene,"HeaderNode",inputs=[],outputs=[])
##                node_header.setPos(self.point.x(),self.point.y())
##                self.header += 1



    


