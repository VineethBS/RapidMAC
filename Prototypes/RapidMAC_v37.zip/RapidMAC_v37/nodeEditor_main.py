# ! /usr/bin/env python 3.6.7
# -*- coding utf-8 -*-

import PyQt5
import sys
import os
import shutil
import pickle
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5 import QtCore,QtWidgets,QtGui
from node_editor_wnd import NodeEditorWnd
from node_node import Node, codefragmenttext, St_Init_node,St_SP_node,St_PI_node,St_On_node,St_Off_node,St_CCI_node
from node_node import Wp_node, Rb_node, Sp_node,Rv_node,Cust_node,Fc_node,Va_node,p_nodeslist,nodeslist
from node_node import Start_Node_Init,Start_Node_SP,Start_Node_PI,Start_Node_On,Start_Node_Off,Start_Node_CCI
from node_node import Waitforpkt_Node,Randombackoff_Node,Sendpacket_Node,ReturnValue_Node,FunctionCall_Node,VariableAssign_Node,CustomCode_Node
from node_edge import Edge, codefragment,Edge_attributes
from node_graphics_view import INIT_content1,INIT_content2,SP_content1,SP_content2,PI_content1,PI_content2,ON_content1,ON_content2,OFF_content1,OFF_content2
from node_graphics_view import CCI_content1,CCI_content2,Ret_textinputs,Custom_textinputs,VarDef_textinputs,FunDef_textinputs,Attributes
from node_graphics_view import headers_text,Header_textinputs
from node_graphics_view import *
from node_graphics_node import QDMGraphicsNode
from node_scene import Scene
import networkx as nx
import matplotlib.pyplot as plt
from contiki_create_headerfile import CreateHeaderfile
from contiki_create_projconfile import CreateProjConfFile
##from node_graphics_view import Driver_name_list

mac_functions = ["init", "send_packet", "packet_input", "on", "off", "channel_check_interval"]
func_blocks = ["Wait for Packet","Random Backoff","Send Packet","Return Value","Function Call","Variable Assignment","Custom Code Block",
               "Function Definition","Variable Definition","Macro Definition","Driver Node","Header Node"]
Dict_db = {}
nodeslist = []

B = nx.DiGraph()

stringline1 = "/**\n"
stringline2 = " * "+"\\"+"file\n"
stringline3 = " * \t\t"+"TDMA with a synchronization beacon implementation (header file)"
stringline4 = "\n * \t\t"+"Modification of TDMA code in Contiki 3.0 by Adam Dunkels"
stringline41 = "\n * \t\t"+"TDMA slotting is done using RTimer while Beaconing is done via CTimer"
stringline5 = "\n * "+"\\"+"author\n"
stringline6 = " *\t\t"+"Vineeth B.S <vineethbs@gmail.com>\n"
stringline7 = " */\n\n"
stringline8 = "#include "+'"'
stringline9 = "\n#include <string.h>\n\n"

contiki_dir_list = []
project_dir_list = []
Driver_name_list = []

class MainWin(QMainWindow):
    def __init__(self):  
        super(MainWin,self).__init__()
        self.list_flag = [0]
        self.application_UI(self.list_flag)

    def application_UI(self,list_flag):
        self.list_flag = list_flag
        self.A = nx.DiGraph()
        self.count = 0
        self.scene = Scene()
        self.node_content = "RAPID MAC - Main Window"
        self.position = PyQt5.QtCore.QPoint(0, 0)
        self.Dp_nodes = []
        self.Dp_edges = []
        codefragment_copy = codefragment.copy()
        self.Attributes = Attributes
        self.Edge_attributes = Edge_attributes
        self.nodeslist = nodeslist

        self.Init_Cust_txt = " "
        self.SP_Cust_txt = " "
        self.PI_Cust_txt = " "
        self.On_Cust_txt = " "
        self.Off_Cust_txt = " "
        self.CCI_Cust_txt = " "
        
        self.Init_Ret_txt = " "
        self.SP_Ret_txt = " "
        self.PI_Ret_txt = " "
        self.On_Ret_txt = " "
        self.Off_Ret_txt = " "
        self.CCI_Ret_txt = " "

##        if QToolBar:
##            removeToolBar()
##
##        if QMenuBar:
##            removeMenuBar

        menubar = self.menuBar()
        
        filemenu = menubar.addMenu('File')
        newfilemenu = QAction('New',self)
        newfilemenu.setStatusTip('New Canvas')
        newfilemenu.triggered.connect(self.newcanvas)
        
        openfilemenu = QAction('Open',self)
        openfilemenu.setStatusTip('Open Pickle File')
        openfilemenu.triggered.connect(self.open_picklefile)
        
        savefilemenu = QAction('Save',self)
        savefilemenu.setStatusTip('Save Canvas as pickle file')
        savefilemenu.triggered.connect(self.savepicklefile)
        
        quitfilemenu = QAction('Quit',self)
        quitfilemenu.setStatusTip('Exit application')
##        quitfilemenu.triggered.connect(qApp.quit)
        quitfilemenu.triggered.connect(self.close_rapidmac)
        
        filemenu.addAction(newfilemenu)
        filemenu.addAction(openfilemenu)
        filemenu.addAction(savefilemenu)
        filemenu.addAction(quitfilemenu)
        

        editmenu = menubar.addMenu('Edit')
        undoeditmenu = QAction('Undo',self)
        undoeditmenu.setStatusTip('Undo change')
        redoeditmenu = QAction('Redo',self)
        redoeditmenu.setStatusTip('Redo change')
        cuteditmenu = QAction('Cut',self)
        cuteditmenu.setStatusTip('Cut selected area')
        copyeditmenu = QAction('Copy',self)
        copyeditmenu.setStatusTip('Copy selected area')
        pasteeditmenu = QAction('Paste',self)
        pasteeditmenu.setStatusTip('Paste copied content')
        editmenu.addAction(undoeditmenu)
        editmenu.addAction(redoeditmenu)
        editmenu.addAction(cuteditmenu)
        editmenu.addAction(copyeditmenu)
        editmenu.addAction(pasteeditmenu)

        viewmenu = menubar.addMenu('View')
        zoominviewmenu = QAction('Zoom in',self)
        zoominviewmenu.setStatusTip('Zoom In')
        zoomoutviewmenu = QAction('Zoom out',self)
        zoomoutviewmenu.setStatusTip('Zoom Out')
        toolbarviewmenu = QMenu('Toolbars',self)
        toolbarviewmenu.setStatusTip('Toolbars')
        toolbarsviewact = QAction('MenuBar',self)
        toolbarsviewact.setStatusTip('MenuBar')
        toolbarviewmenu.addAction(toolbarsviewact)
        viewmenu.addAction(zoominviewmenu)
        viewmenu.addAction(zoomoutviewmenu)
        viewmenu.addMenu(toolbarviewmenu)
        
        contikicodemenu = menubar.addMenu('Contiki Code')
        settingsmenu = QAction('Settings',self)
        settingsmenu.setStatusTip('Settings for Code Generation for Contiki OS')
        settingsmenu.triggered.connect(self.contiki_settings)
        
        generatemenu = QAction('Generate',self)
        generatemenu.setStatusTip('Generate C-file in net/mac folder')
        generatemenu.triggered.connect(self.contiki_generate)
        
        uploadmenu = QAction('Upload to Dev',self)
        uploadmenu.setStatusTip('Upload contiki code to device')
        uploadmenu.triggered.connect(self.uploadtodevice)
        
        contikicodemenu.addAction(settingsmenu)
        contikicodemenu.addAction(generatemenu)
        contikicodemenu.addAction(uploadmenu)
        
        toolbar = QToolBar('My Toolbar')
        toolbar.setIconSize(QSize(25,25))
        self.addToolBar(toolbar)
        
        btn1 = QAction(QIcon("nodesimg.png"),'Nodes', self)
        btn1.setCheckable(True)
        toolbar.addAction(btn1)
        btn2 = QAction(QIcon("edgesimg.png"),'Edges', self)
        btn2.setCheckable(True)
        toolbar.addAction(btn2)
        btn3 = QAction(QIcon("selectimg.png"),'Select', self)
        btn3.setCheckable(True)
        toolbar.addAction(btn3)
        btn4 = QAction(QIcon("savefile.png"),'Save File', self)
        btn4.setCheckable(True)
        toolbar.addAction(btn4)
        btn4.triggered.connect(self.generate_code)    

##        newfilemenu.triggered.connect(self.newcanvas)
        
        listsplitter = QFrame()
        label1 = QLabel()
        label1.setText('MAC Functions:')
        label1.setStyleSheet('font: 18px;')

        label2 = QLabel()
        label2.setText('Functional Blocks:')
        label2.setStyleSheet('font: 18px;')

        self.list1 = QListWidget()
        for i in range (6): self.list1.addItem(mac_functions[i])
        self.list1.clicked.connect(self.listbox1_clicked)
        
        self.list2 = QListWidget()
        for i in range (12): self.list2.addItem(func_blocks[i])
        self.list2.clicked.connect(self.listbox2_clicked)

        self.left = NodeEditorWnd(self,self.list_flag)

        splitter1 = QSplitter(Qt.Horizontal)

        layout = QVBoxLayout()

        layout.addWidget(label1)
        layout.addWidget(self.list1)
        layout.addWidget(label2)
        layout.addWidget(self.list2)

        listsplitter.setLayout(layout)
        
        splitter1.addWidget(self.left)
        splitter1.addWidget(listsplitter)
        splitter1.setSizes([800,30])
        
        self.statusBar().showMessage('Ready')
        self.showMaximized()
        self.setCentralWidget(splitter1)     
        self.setWindowTitle('Rapid MAC')
        self.show()

    def listbox1_clicked(self):
        item = self.list1.currentItem()
        if str(item.text()) == mac_functions[0]:
            self.list_flag[0] = 1
            self.statusBar().showMessage(mac_functions[0])
        if str(item.text()) == mac_functions[1]:
            self.list_flag[0] = 2
            self.statusBar().showMessage(mac_functions[1])
        if str(item.text()) == mac_functions[2]:
            self.list_flag[0] = 3
            self.statusBar().showMessage(mac_functions[2])
        if str(item.text()) == mac_functions[3]:
            self.list_flag[0] = 4
            self.statusBar().showMessage(mac_functions[3])
        if str(item.text()) == mac_functions[4]:
            self.list_flag[0] = 5
            self.statusBar().showMessage(mac_functions[4])
        if str(item.text()) == mac_functions[5]:
            self.list_flag[0] = 6
            self.statusBar().showMessage(mac_functions[5])

    def listbox2_clicked(self):
        item = self.list2.currentItem()
        if str(item.text()) == func_blocks[0]:
            self.list_flag[0] = 7
            self.statusBar().showMessage(func_blocks[0])
        if str(item.text()) == func_blocks[1]:
            self.list_flag[0] = 8
            self.statusBar().showMessage(func_blocks[1])
        if str(item.text()) == func_blocks[2]:
            self.list_flag[0] = 9
            self.statusBar().showMessage(func_blocks[2])
        if str(item.text()) == func_blocks[3]:
            self.list_flag[0] = 10
            self.statusBar().showMessage(func_blocks[3])
        if str(item.text()) == func_blocks[4]:
            self.list_flag[0] = 11
            self.statusBar().showMessage(func_blocks[4])
        if str(item.text()) == func_blocks[5]:
            self.list_flag[0] = 12
            self.statusBar().showMessage(func_blocks[5])
        if str(item.text()) == func_blocks[6]:
            self.list_flag[0] = 13
            self.statusBar().showMessage(func_blocks[6])
        if str(item.text()) == func_blocks[7]:
            self.list_flag[0] = 14
            self.statusBar().showMessage(func_blocks[7])
        if str(item.text()) == func_blocks[8]:
            self.list_flag[0] = 15
            self.statusBar().showMessage(func_blocks[8])
        if str(item.text()) == func_blocks[9]:
            self.list_flag[0] = 16
            self.statusBar().showMessage(func_blocks[9])
        if str(item.text()) == func_blocks[10]:
            self.list_flag[0] = 17
            self.statusBar().showMessage(func_blocks[10])
        if str(item.text()) == func_blocks[11]:
            self.list_flag[0] = 18
            self.statusBar().showMessage(func_blocks[11])

    def newcanvas(self):
##        self.close()
        self.list_flag[0] = 0
##        self.left.close()
##        self.left.show()
        ex.close()
        MainWin.application_UI(self,self.list_flag)
##        eg = MainWin()
##        eg.show()
        
 #       self.left.show()


    def open_picklefile(self):
        self.list_flag[0] = 100
        MainWin.application_UI(self,self.list_flag)
##        self.left.close()
##        self.left = NodeEditorWnd(self,self.list_flag)
##        self.left.close()
##        self.left.show()
##        eg = MainWin()
##        eg.show()
        
##        options = QFileDialog.Options()
##        options |= QFileDialog.DontUseNativeDialog
##        fileName = QFileDialog.getOpenFileName(self,"Open pickle file...","","All Files (*);;pickle Files (*.gpickle)", options=options)
##        G = nx.read_gpickle(fileName[0])
##        self.left.show()
##        QDMGraphicsView.depickling(self,G)

    def contiki_settings(self):
        self.display_settings = ContikiSettings()
        self.display_settings.show()
        
    def savebuttonClicked(self):
##        print('----------to copy')
        codefragment_copy = []
        self.Flow1 = []
        self.Flow2 = []
        self.Flow3 = []
        self.Flow4 = []
        self.Flow5 = []
        self.Flow6 = []
        
        self.st1 = len(St_Init_node)
        self.st2 = len(St_SP_node)
        self.st3 = len(St_PI_node)
        self.st4 = len(St_On_node)
        self.st5 = len(St_Off_node)
        self.st6 = len(St_CCI_node)

        for i in range (len(codefragment)):
            codefragment_copy.append(codefragment[i])

        for i in range (len(codefragment_copy)):

            k = codefragment_copy[0]

            if k[0] in St_Init_node:
                self.Flow1.append(k)
                codefragment_copy.remove(k)
                for j in range (len(codefragment_copy)):
                    k1 = codefragment_copy[j]
                    if k1[0] == k[1]:
                        self.Flow1.append(k1)
                        codefragment_copy.remove(k1)
                        for m in range (len(codefragment_copy)):
                            k2 = codefragment_copy[m]
                            if k2[0] == k1[1]:
                                self.Flow1.append(k2)
                                codefragment_copy.remove(k2)
                                break
                        break
            
            if k[0] in St_SP_node:
                self.Flow2.append(k)
                codefragment_copy.remove(k)
                for j in range (len(codefragment_copy)):
                    k1 = codefragment_copy[j]
                    if k1[0] == k[1]:
                        self.Flow2.append(k1)
                        codefragment_copy.remove(k1)
                        for m in range (len(codefragment_copy)):
                            k2 = codefragment_copy[m]
                            if k2[0] == k1[1]:
                                self.Flow2.append(k2)
                                codefragment_copy.remove(k2)
                                break
                        break
            if k[0] in St_PI_node:
                self.Flow3.append(k)
                codefragment_copy.remove(k)
                for j in range (len(codefragment_copy)):
                    k1 = codefragment_copy[j]
                    if k1[0] == k[1]:
                        self.Flow3.append(k1)
                        codefragment_copy.remove(k1)
                        for m in range (len(codefragment_copy)):
                            k2 = codefragment_copy[m]
                            if k2[0] == k1[1]:
                                self.Flow3.append(k2)
                                codefragment_copy.remove(k2)
                                break
                        break
            if k[0] in St_On_node:
                self.Flow4.append(k)           
                codefragment_copy.remove(k)
                for j in range (len(codefragment_copy)):
                    k1 = codefragment_copy[j]
                    if k1[0] == k[1]:
                        self.Flow4.append(k1)
                        codefragment_copy.remove(k1)
                        for m in range (len(codefragment_copy)):
                            k2 = codefragment_copy[m]
                            if k2[0] == k1[1]:
                                self.Flow4.append(k2)
                                codefragment_copy.remove(k2)
##                                for n in range (len(codefragment_copy)):
##                                    k3 = codefragment_copy[n]
##                                    if k3[0] == k2[1]:
##                                        self.Flow4.append(k3)
##                                        codefragment_copy.remove(k3)
##                                        break
                                break
                        break
            if k[0] in St_Off_node:
                self.Flow5.append(k)
                codefragment_copy.remove(k)
                for j in range (len(codefragment_copy)):
                    k1 = codefragment_copy[j]
                    if k1[0] == k[1]:
                        self.Flow5.append(k1)
                        codefragment_copy.remove(k1)
                        for m in range (len(codefragment_copy)):
                            k2 = codefragment_copy[m]
                            if k2[0] == k1[1]:
                                self.Flow5.append(k2)
                                codefragment_copy.remove(k2)
##                                for n in range (len(codefragment_copy)):
##                                    k3 = codefragment_copy[n]
##                                    if k3[0] == k2[1]:
##                                        self.Flow5.append(k3)
##                                        codefragment_copy.remove(k3)
##                                        break
                                break
                        break
            if k[0] in St_CCI_node:
                self.Flow6.append(k)
                codefragment_copy.remove(k)
                for j in range (len(codefragment_copy)):
                    k1 = codefragment_copy[j]
                    if k1[0] == k[1]:
                        self.Flow6.append(k1)
                        codefragment_copy.remove(k1)
                        for m in range (len(codefragment_copy)):
                            k2 = codefragment_copy[m]
                            if k2[0] == k1[1]:
                                self.Flow6.append(k2)
                                codefragment_copy.remove(k2)
##                                for n in range (len(codefragment_copy)):
##                                    k3 = codefragment_copy[n]
##                                    if k3[0] == k2[1]:
##                                        self.Flow6.append(k3)
##                                        codefragment_copy.remove(k3)
##                                        break
                                break
                        break
            if (len(codefragment_copy)) != 0:
                continue
            else:
                break

    def generate_code(self):
        self.savebuttonClicked()
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        self.cfileName, _ = QFileDialog.getSaveFileName(self,"Save generated code (.c)...","","All Files (*);;C Files (*.c)", options=options)
        
        if self.cfileName:
            with open (self.cfileName,'w') as self.myfile:
                if self.st1 == 1 and self.st2 == 1 and self.st3 == 1 and self.st4 == 1 and self.st5 == 1 and self.st6 == 1:
                    self.myfile.write(stringline1)
                    self.myfile.write(stringline2)
                    self.myfile.write(stringline3)
                    self.myfile.write(stringline4)
                    self.myfile.write(stringline41)
                    self.myfile.write(stringline5)
                    self.myfile.write(stringline6)
                    self.myfile.write(stringline7)

                    if (len(Header_textinputs)) != 0:
                        for a in range (len(Header_textinputs)):
                            temp = Header_textinputs[a]
                            self.myfile.write("\n")
                            self.myfile.write(temp[1])

                    self.myfile.write("\n/*---------------------------------------------------------------------------------*/\n")

                    if (len(MacroDef_textinputs)) != 0:
                        for h in range (len(MacroDef_textinputs)):
                            temp = MacroDef_textinputs[h]
                            self.myfile.write("\n")
                            self.myfile.write(temp[1])

                    self.myfile.write("\n/*---------------------------------------------------------------------------------*/\n")

                    if (len(VarDef_textinputs)) != 0:
                        for j in range (len(VarDef_textinputs)):
                            temp = VarDef_textinputs[j]
                            self.myfile.write("\n")
                            self.myfile.write(temp[1])

                    self.myfile.write("\n/*---------------------------------------------------------------------------------*/\n")
                            
                    if (len(FunDef_textinputs)) != 0:
                        for g in range (len(FunDef_textinputs)):
                            temp = FunDef_textinputs[g]
                            self.myfile.write("\n")
                            self.myfile.write(temp[1])

                    self.myfile.write("\n/*---------------------------------------------------------------------------------*/\n")

                    if (len(Custom_textinputs)) != 0:
                        for h in range (len(Custom_textinputs)):
                            temp = Custom_textinputs[h]
                            self.myfile.write("\n")
                            self.myfile.write(temp[1])

                    self.myfile.write("\n/*---------------------------------------------------------------------------------*/\n")

##                    for s in range (len(self.Flow1)):
##                        w = self.Flow1[s]
##                        for s1 in range (len(Custom_textinputs)):
##                            w1 = Custom_textinputs[s1]
##                            if w1[0] == w[1]:
##                                self.Init_Cust_txt = w1[1]
##        ##                            break
##                        for t in range (len(Ret_textinputs)):
##                            x = Ret_textinputs[t]
##                            if x[0] == w[1]:
##                                self.Init_Ret_txt = x[1]
##        ##                            break
##                    if self.Init_Cust_txt is None:
##                        self.Init_Cust_txt = " "
##                    if self.Init_Ret_txt is None:
##                        self.Init_Ret_txt = " "
##                    self.init_custom_code = INIT_content1 + self.Init_Cust_txt + self.Init_Ret_txt + INIT_content2
##
##                    self.myfile.write("\n")
##                    self.myfile.write(self.init_custom_code)
##                    self.myfile.write("\n/*---------------------------------------------------------------------------------*/\n")
##                    
##                    for s in range (len(self.Flow2)):
##                        w = self.Flow2[s]
##                        for s1 in range (len(Custom_textinputs)):
##                            w1 = Custom_textinputs[s1]
##                            if w1[0] == w[1]:
##                                self.SP_Cust_txt = w1[1]
##                        for t in range (len(Ret_textinputs)):
##                            x = Ret_textinputs[t]
##                            if x[0] == w[1]:
##                                self.SP_Ret_txt = x[1]
##                    if self.SP_Cust_txt is None:
##                        self.SP_Cust_txt = " "
##                    if self.SP_Ret_txt is None:
##                        self.SP_Ret_txt = " "
##                    self.SP_custom_code = SP_content1 + self.SP_Cust_txt + self.SP_Ret_txt + SP_content2
##
##                    self.myfile.write("\n")
##                    self.myfile.write(self.SP_custom_code)
##                    self.myfile.write("\n/*---------------------------------------------------------------------------------*/\n")
##
##                    for s in range (len(self.Flow3)):
##                        w = self.Flow3[s]
##                        for s1 in range (len(Custom_textinputs)):
##                            w1 = Custom_textinputs[s1]
##                            if w1[0] == w[1]:
##                                self.PI_Cust_txt = w1[1]
##                        for t in range (len(Ret_textinputs)):
##                            x = Ret_textinputs[t]
##                            if x[0] == w[1]:
##                                self.PI_Ret_txt = x[1]
##                    if self.PI_Cust_txt is None:
##                        self.PI_Cust_txt = " "
##                    if self.PI_Ret_txt is None:
##                        self.PI_Ret_txt = " "
##                    self.PI_custom_code = PI_content1 + self.PI_Cust_txt + self.PI_Ret_txt + PI_content2
##
##                    self.myfile.write("\n")
##                    self.myfile.write(self.PI_custom_code)
##                    self.myfile.write("\n/*---------------------------------------------------------------------------------*/\n")
                    
                    for s in range (len(self.Flow4)):
                        w = self.Flow4[s]
                        for s1 in range (len(Custom_textinputs)):
                            w1 = Custom_textinputs[s1]
                            if w1[0] == w[1]:
                                self.On_Cust_txt = w1[1]
                        for t in range (len(Ret_textinputs)):
                            x = Ret_textinputs[t]
                            if x[0] == w[1]:
                                self.On_Ret_txt = x[1]
                    if self.On_Cust_txt is None:
                        self.On_Cust_txt = " "
                    if self.On_Ret_txt is None:
                        self.On_Ret_txt = " "
                    self.myfile.write("\n")
                    self.custom_code = ON_content1 + self.On_Cust_txt + self.On_Ret_txt + ON_content2
                    self.myfile.write(self.custom_code)
                    self.myfile.write("\n/*---------------------------------------------------------------------------------*/\n")
                    

                    for s in range (len(self.Flow5)):
                        w = self.Flow5[s]
                        for s1 in range (len(Custom_textinputs)):
                            w1 = Custom_textinputs[s1]
                            if w1[0] == w[1]:
                                self.Off_Cust_txt = w1[1]
                        for t in range (len(Ret_textinputs)):
                            x = Ret_textinputs[t]
                            if x[0] == w[1]:
                                self.Off_Ret_txt = x[1]

                    if self.Off_Cust_txt is None:
                        self.Off_Cust_txt = " "
                    if self.Off_Ret_txt is None:
                        self.Off_Ret_txt = " "
                    self.myfile.write("\n")
                    self.return_code = OFF_content1 + self.Off_Cust_txt + self.Off_Ret_txt + OFF_content2
                    self.myfile.write(self.return_code)
                    self.myfile.write("\n/*---------------------------------------------------------------------------------*/\n")
                   
                    
                    for s in range (len(self.Flow6)):
                        w = self.Flow6[s]
                        for s1 in range (len(Custom_textinputs)):
                            w1 = Custom_textinputs[s1]
                            if w1[0] == w[1]:
                                self.CCI_Cust_txt = w1[1]
                        for t in range (len(Ret_textinputs)):
                            x = Ret_textinputs[t]
                            if x[0] == w[1]:
                                self.CCI_Ret_txt = x[1]

                    if self.CCI_Cust_txt is None:
                        self.CCI_Cust_txt = " "
                    if self.CCI_Ret_txt is None:
                        self.CCI_Ret_txt = " "
                    self.myfile.write("\n")
                    self.channel_code = CCI_content1 + self.CCI_Cust_txt + self.CCI_Ret_txt + CCI_content2
                    self.myfile.write(self.channel_code)
                    self.myfile.write("\n/*---------------------------------------------------------------------------------*/\n")

                    if (len(Driver_textinputs)) != 0:
                        for g in range (len(Driver_textinputs)):
                            temp = Driver_textinputs[g]
                            self.myfile.write("\n")
                            self.myfile.write(temp[1])

                    self.myfile.write("\n/*---------------------------------------------------------------------------------*/\n")

                else: 
                    print('**********...ALL START NODES ARE NOT CREATED...************')

    def draw_nxgraph(self):
        for a in range (len(Custom_textinputs)):
            temp = Custom_textinputs[a]
            for key,val in self.Attributes.items():
                for attr,values in val.items():
                    self.Attributes[temp[0]]['contents'] = temp[1]

        for b in range (len(Ret_textinputs)):
            temp = Ret_textinputs[b]
            for key,val in self.Attributes.items():
                for attr,values in val.items():
                    self.Attributes[temp[0]]['contents'] = temp[1]

        for c in range (len(FunDef_textinputs)):
            temp = FunDef_textinputs[c]
            for key,val in self.Attributes.items():
                for attr,values in val.items():
                    self.Attributes[temp[0]]['contents'] = temp[1]

        for d in range (len(VarDef_textinputs)):
            temp = VarDef_textinputs[d]
            for key,val in self.Attributes.items():
                for attr,values in val.items():
                    self.Attributes[temp[0]]['contents'] = temp[1]

        for e in range (len(MacroDef_textinputs)):
            temp = MacroDef_textinputs[e]
            for key,val in self.Attributes.items():
                for attr,values in val.items():
                    self.Attributes[temp[0]]['contents'] = temp[1]

        for f in range (len(Driver_textinputs)):
            temp = Driver_textinputs[f]
            for key,val in self.Attributes.items():
                for attr,values in val.items():
                    self.Attributes[temp[0]]['contents'] = temp[1]

        for g in range (len(Header_textinputs)):
            temp = Header_textinputs[g]
            for key,val in self.Attributes.items():
                for attr,values in val.items():
                    self.Attributes[temp[0]]['contents'] = temp[1]

        for t in range (len(nodeslist)):
            for key,val in self.Attributes.items():
                for attr,values in val.items():
                    self.Attributes[hex(id(p_nodeslist[t]))]['pos'] = nodeslist[t].pos()

        self.A.clear()
        self.A.add_nodes_from(p_nodeslist)
        nx.set_node_attributes(self.A, self.Attributes)
        self.A.add_edges_from(codefragment)
        nx.set_edge_attributes(self.A, self.Edge_attributes)
        
        nx.draw(self.A,with_labels = True)
        print(nx.info(self.A))
        plt.show()
        
    def close_rapidmac(self):

        self.disp_dialog = Quit_RMAC(self.A)
        self.disp_dialog.show()
        
        
    def savepicklefile(self):
        self.draw_nxgraph()

        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        fileName = QFileDialog.getSaveFileName(self,"Save pickle file...","","All Files (*);;pickle Files (*.gpickle)", options=options)
        
        nx.write_gpickle(self.A,fileName[0])
       
    def contiki_generate(self):
        self.generate_code()
     
        self.gen = CreateHeaderfile(Driver_name_list)
        self.pcgen = CreateProjConfFile(project_dir_list,Driver_name_list)

    def uploadtodevice(self):
        print('\nuploading......')
        os.system('cd contiki/examples/rime')
        os.system('make TARGET=sky savetarget')
        os.system('sudo make radio-test.upload MOTES=/dev/ttyUSB0')
        os.system('sudo make login TARGET=sky MOTES=/dev/ttyUSB0')
        print('\n.....\n.........\nsuccessfully uploaded to device .....')
        
##        with open('/home/sherine/contiki/examples/rime/project-conf.h','r') as projconfile:
##            data = projconfile.readlines()
##            for line in data:
##                if "NETSTACK_CONF_MAC" in line:
##                    oriline = line
##                    newline = line.replace(line[31:41],Driver_name_list[-1])


##        filein = open('/home/sherine/contiki/examples/rime/project-conf.h','r')
##        fileout = open('/home/sherine/contiki/examples/rime/project-conf.h','w')
####        with open ('/home/sherine/contiki/examples/rime/project-conf.h','r') as projconfile:
##        for line in filein:
##            text = filein.read().strip().split()
##            while True:
##                if "NETSTACK_CONF_MAC" == "":
##                    line = line[:30] + Driver_name_list[-1] + line[41:]
##                fileout.write(line)
##
##        filein.close()
##        fileout.close()
    

class Quit_RMAC(QDialog):
    def __init__(self,B):
        super().__init__()
##        MainWin.__init__(self)
        
        self.B = B
##
##        nx.draw(self.B,with_labels = True)
##        print(nx.info(self.B))
##        plt.show()
        
##        QMessageBox.about(self, "Do you want to save before closing ?")
        quit_label = QLabel()
        quit_label.setText('Do you want to save before closing ?')
        quit_label.setStyleSheet('font: 16px;')

        self.quit_yes = QPushButton('Yes')
        self.quit_yes.clicked.connect(self.yes_save)

        self.quit_no = QPushButton('No')
        self.quit_no.clicked.connect(self.no_save)

        self.quit_cancel = QPushButton('Cancel')
        self.quit_cancel.clicked.connect(self.cancel_quit)


        buttons_layout = QHBoxLayout()
        buttons_layout.addWidget(self.quit_yes)
        buttons_layout.addWidget(self.quit_no)
        buttons_layout.addWidget(self.quit_cancel)

        dialog_layout = QVBoxLayout()
        dialog_layout.addWidget(quit_label)
        dialog_layout.addLayout(buttons_layout)

        self.setLayout(dialog_layout)
        self.setWindowTitle("Save On Close")

    def yes_save(self):
        print('Yes............................')
        print('self.B :',self.B)
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        fileName = QFileDialog.getSaveFileName(self,"Save pickle file...","","All Files (*);;pickle Files (*.gpickle)", options=options)
        
        nx.write_gpickle(self.B,fileName[0])
        
        print(nx.info(self.B))
##        eg = MainWin()
        self.close()
        ex.close()

    def no_save(self):
        print('No....................')
        self.close()
        ex.close()
##        qApp.quit()


    def cancel_quit(self):
        print('cancel...............')
        self.close()
        pass
              
        
class ContikiSettings(QDialog):
    def __init__(self):
        super().__init__()

        settings_label1 = QLabel()
        settings_label1.setText('Contiki Code Directory:')
        settings_label1.setStyleSheet('font: 14px;')
        self.settingsedit1 = QLineEdit()
        self.select_button = QPushButton('...')
        self.select_button.clicked.connect(self.open_contiki_dir)
        
        self.settings_layout1 = QHBoxLayout()
        self.settings_layout1.addWidget(settings_label1)
        self.settings_layout1.addWidget(self.settingsedit1)
        self.settings_layout1.addWidget(self.select_button)

        settings_label2 = QLabel()
        settings_label2.setText('Project Config. File Directory:')
        settings_label2.setStyleSheet('font: 14px;')
        self.settingsedit2 = QLineEdit()
        self.projectconf_select_button = QPushButton('...')
        self.projectconf_select_button.clicked.connect(self.open_projectconf)

        self.settings_layout2 = QHBoxLayout()
        self.settings_layout2.addWidget(settings_label2)
        self.settings_layout2.addWidget(self.settingsedit2)
        self.settings_layout2.addWidget(self.projectconf_select_button)

        settings_label3 = QLabel()
        settings_label3.setText('MAC_Driver Name:')
        settings_label3.setStyleSheet('font: 14px;')
        self.settingsedit3 = QLineEdit()

        self.settings_layout3 = QHBoxLayout()
        self.settings_layout3.addWidget(settings_label3)
        self.settings_layout3.addWidget(self.settingsedit3)
        
        self.OK_button = QPushButton('OK')
        self.OK_button.clicked.connect(self.settings_ok)

        self.settings_layout4 = QVBoxLayout()
        self.settings_layout4.addLayout(self.settings_layout2)
        self.settings_layout4.addLayout(self.settings_layout1)
        self.settings_layout4.addLayout(self.settings_layout3)
        self.settings_layout4.addWidget(self.OK_button)

        self.setLayout(self.settings_layout4)
        self.setWindowTitle('Contiki Code Directory')

        if (len(contiki_dir_list)) != 0:
            self.settingsedit1.setText(str(contiki_dir_list[-1]))
        if (len(project_dir_list)) != 0:
            self.settingsedit2.setText(str(project_dir_list[-1]))

    def open_contiki_dir(self):
        self.contiki_code_dir = str(QFileDialog.getExistingDirectory(self, "Select Contiki code Directory"))
        self.settingsedit1.setText(self.contiki_code_dir)

    def open_projectconf(self):
        self.project_conf_dir = str(QFileDialog.getExistingDirectory(self, "Select Project Configuration File Directory"))
        self.settingsedit2.setText(self.project_conf_dir)

    def settings_ok(self):
##        self.Driver_name_list = []
##        if (len(Driver_name_list)) != 0:
##            del Driver_name_list
        self.contiki_code_dir = self.settingsedit1.text()
        self.project_conf_dir = self.settingsedit2.text()
        self.mac_driver_name = self.settingsedit3.text()
        if not self.mac_driver_name:
            QMessageBox.about(self, "MAC_Driver Name !", "Enter MAC_Driver Name and click OK !")
        Driver_name_list.append(self.mac_driver_name)
        if (len(contiki_dir_list)) != 0: del contiki_dir_list[-1]
        if (len(project_dir_list)) != 0: del project_dir_list[-1]

        contiki_dir_list.append(self.contiki_code_dir)
        project_dir_list.append(self.project_conf_dir)

        self.close()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainWin()
    sys.exit(app.exec_())


