/**
 * \file
 * 		TDMA with a synchronization beacon implementation (header file)
 * 		Modification of TDMA code in Contiki 3.0 by Adam Dunkels
 * 		TDMA slotting is done using RTimer while Beaconing is done via CTimer
 * \author
 *		Vineeth B.S <vineethbs@gmail.com>
 */


net/rime/rime.h
net/queuebuf.h
net/ip/uip.h
string.h
#define qqqq 1111
#define aaa 12122

#if DEBUG
#include <stdio.h>
#define PRINTF(...) printf(__VA_ARGS__)
#else /* DEBUG */
#define PRINTF(...)
#endif /* DEBUG */
qq ww;
qwqw ddfd3434 = 6666666;
f1 n1()
{
eeeeee;
rrrrrrrrrr;

}
f2 n2(a3,a31)
{
d1;
d2;
d3;
}
f1 n1()
{
eeeeee;
rrrrrrrrrr;

}
f2 n2(a3,a31)
{
d1;
d2;
d3;
}
static void
init(void)
{
  
}
/*---------------------------------------------------------------------------------*/

static void 
send_packet(mac_callback_t sent, void *ptr)
{
  
}
/*---------------------------------------------------------------------------------*/

static void 
packet_input(void)
{
  
}
/*---------------------------------------------------------------------------------*/

static int
on(void)
{
  ;
}
/*---------------------------------------------------------------------------------*/

static int
off(int keep_radio_on)
{
  ;
}
/*---------------------------------------------------------------------------------*/

static unsigned short
channel_check_interval(void)
{
  ;
}
/*---------------------------------------------------------------------------------*/

drv type1 mac_driver DRIVR_NICKJUNIOR = {
cont1,
cont2,
cont3,
};
