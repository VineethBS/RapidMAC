/**
 * \file
 * 		TDMA with a synchronization beacon implementation (header file)
 * 		Modification of TDMA code in Contiki 3.0 by Adam Dunkels
 * 		TDMA slotting is done using RTimer while Beaconing is done via CTimer
 * \author
 *		Vineeth B.S <vineethbs@gmail.com>
 */


static void
init(void)
{
ttt1 nnnn1(aa1,aa2)
{
codeline1;
codeline2;
codeline3;
}
ttt2 nnnnnn2(aa4,aa3)
{
codeline1;
code_line_2;
code_line_3;
} 
}
/*---------------------------------------------------------------------------------*/

static void 
send_packet(mac_callback_t sent, void *ptr)
{
  
}
/*---------------------------------------------------------------------------------*/

static void 
packet_input(void)
{
  
}
/*---------------------------------------------------------------------------------*/

static int
on(void)
{
  ;
}
/*---------------------------------------------------------------------------------*/

static int
off(int keep_radio_on)
{
  ;
}
/*---------------------------------------------------------------------------------*/

static unsigned short
channel_check_interval(void)
{
  ;
}
/*---------------------------------------------------------------------------------*/
