import sys
from PyQt5.QtWidgets import (
        QApplication, QWidget, QLabel, QPushButton, QTextEdit, QFrame
    )
from PyQt5.QtCore import pyqtSlot, QRect, Qt

class MainPage(QWidget):
    def __init__(self, title=" "):
        super().__init__()  # inherit init of QWidget
        self.title = title
        self.left = 250
        self.top = 250
        self.width = 350
        self.height = 300
        self.widget()

    def widget(self):
        # window setup
        self.setWindowTitle(self.title)
        # self.setGeometry(self.left, self.top, self.width, self.height)
        ## use above line or below
        self.resize(self.width, self.height)
        self.move(self.left, self.top)

        # create frame for a set of checkbox
        self.frame1 = QFrame(self)
        self.frame1.setGeometry(QRect(40, 40, 300, 180))
        # create text edit box
        self.text_edit1 = QTextEdit(self.frame1)
        self.text_edit1.move(0, 0)

        button = QPushButton('OK', self)
##        button.resize(100,32)
        button.move(250, 250) 
        button.clicked.connect(self.savetext)
        self.show()
        
##        self.text_edit1.textChanged.connect(self.savetext)
        

    def savetext(self):
        print("OK button clicked")
        self.close()
        self.textvalue = self.text_edit1.document().toPlainText()
        print('--------------------\n',self.textvalue)
        

def main():
    app = QApplication(sys.argv)
    w = MainPage(title="Enter your code here")
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()

