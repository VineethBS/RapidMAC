from PyQt5.QtWidgets import QGraphicsView,QMessageBox
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from node_graphics_socket import QDMGraphicsSocket
from node_graphics_edge import QDMGraphicsEdge
from node_edge import Edge, EDGE_TYPE_BEZIER
from node_node import Node,Start_Node_Init,Start_Node_SP,Start_Node_PI,Start_Node_On
from node_node import Start_Node_Off,Start_Node_CCI,Waitforpkt_Node,Randombackoff_Node,Sendpacket_Node
import networkx as nx

MODE_NOOP = 1
MODE_EDGE_DRAG = 2
EDGE_DRAG_START_THRESHOLD = 10
DEBUG = False

class QDMGraphicsView(QGraphicsView):
    def __init__(self, grScene,scene, net, list_flag, parent=None):
        super().__init__(parent)
        self.grScene = grScene
        self.scene = scene
        self.net = net
##        self.nodename = nodename
        self.list_flag = list_flag
##        self.startnode = 0
        self.st_init = 0
        self.st_sp = 0
        self.st_pi = 0
        self.st_on = 0
        self.st_off = 0
        self.st_cci = 0
        self.initUI()

        self.setScene(self.grScene)

        self.mode = MODE_NOOP

        self.zoomInFactor = 1.25
        self.zoomClamp = True
        self.zoom = 10
        self.zoomStep = 1
        self.zoomRange = [0, 10]

        return 

    def initUI(self):
        self.setRenderHints(QPainter.Antialiasing | QPainter.HighQualityAntialiasing | 
                    QPainter.TextAntialiasing | QPainter.SmoothPixmapTransform)
        self.setViewportUpdateMode(QGraphicsView.FullViewportUpdate)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)

    def mousePressEvent(self,event):
        if event.button() == Qt.MiddleButton:
            self.middleMouseButtonPress(event)
        elif event.button() == Qt.LeftButton:
            self.leftMouseButtonPress(event)
        elif event.button() == Qt.RightButton:
            self.rightMouseButtonPress(event)
        else:
            super().mousePressEvent(event)


    def mouseReleaseEvent(self,event):
        if event.button() == Qt.MiddleButton:
            self.middleMouseButtonRelease(event)
        elif event.button() == Qt.LeftButton:
            self.leftMouseButtonRelease(event)
        elif event.button() == Qt.RightButton:
            self.rightMouseButtonRelease(event)
        else:
            super().mouseReleaseEvent(event)

    def middleMouseButtonPress(self, event):
        releaseEvent = QMouseEvent(QEvent.MouseButtonRelease, event.localPos(), event.screenPos(),
                        Qt.LeftButton, Qt.NoButton, event.modifiers())
        super().mouseReleaseEvent(releaseEvent)
        self.setDragMode(QGraphicsView.ScrollHandDrag)
        fakeEvent = QMouseEvent(event.type(), event.localPos(), event.screenPos(),
                    Qt.LeftButton, event.buttons() | Qt.LeftButton, event.modifiers())
        super().mousePressEvent(fakeEvent)

    def middleMouseButtonRelease(self,event):
        fakeEvent = QMouseEvent(event.type(), event.localPos(), event.screenPos(),
                    Qt.LeftButton, event.buttons() & -Qt.LeftButton, event.modifiers())
        super().mouseReleaseEvent(fakeEvent)
        self.setDragMode(QGraphicsView.NoDrag)

    def leftMouseButtonPress(self,event):
        item = self.getItemAtClick(event)

        if item is None:
            p = self.mapToScene(event.pos())
            self.create_nodes(p)

        self.last_lmb_click_scene_pos = self.mapToScene(event.pos())

        if type(item) is QDMGraphicsSocket:
            if self.mode == MODE_NOOP:
                self.mode = MODE_EDGE_DRAG
                self.edgeDragStart(item)
                return

        if self.mode == MODE_EDGE_DRAG:
            res = self.edgeDragEnd(item)
            if res: return

        super().mousePressEvent(event)

    def leftMouseButtonRelease(self, event):
        item = self.getItemAtClick(event)

        if self.mode == MODE_EDGE_DRAG:
            if self.distanceBetweenClickAndReleaseIsOff(event):
                res = self.edgeDragEnd(item)
                if res: return

        super().mouseReleaseEvent(event)

    def mouseMoveEvent(self, event):
##        print('.....node_graphics_view : mouseMoveEvent')
        if self.mode == MODE_EDGE_DRAG:
            pos = self.mapToScene(event.pos())
            self.dragEdge.grEdge.setDestination(pos.x(), pos.y())
            self.dragEdge.grEdge.update()

        super().mouseMoveEvent(event)
  
    def getItemAtClick(self, event):
        """ return the object on which we've clicked/release mouse button """
        pos = event.pos()
        obj = self.itemAt(pos)
        return obj

    def edgeDragStart(self, item):
        if DEBUG: print('View::edgeDragStart ~ Start dragging edge')
        if DEBUG: print('View::edgeDragStart ~   assign Start Socket')
        if DEBUG: print('View::edgeDragStart ~   assign Start Socket to:', item.socket)
        self.previousEdge = item.socket.edge
        self.last_start_socket = item.socket
        self.dragEdge = Edge(self.grScene.scene, self.net, item.socket, None, EDGE_TYPE_BEZIER)
        if DEBUG: print('View::edgeDragStart ~   dragEdge:', self.dragEdge)

    def edgeDragEnd(self, item):
        """ return True if skip the rest of the code """
        self.mode = MODE_NOOP
        if type(item) is QDMGraphicsSocket:
            if DEBUG: print('View::edgeDragEnd ~   previous edge:', self.previousEdge)
            if item.socket.hasEdge():
                item.socket.edge.remove()
            if DEBUG: print('View::edgeDragEnd ~   assign End Socket', item.socket)
            if self.previousEdge is not None: self.previousEdge.remove()
            if DEBUG: print('View::edgeDragEnd ~  previous edge removed')
            self.dragEdge.start_socket = self.last_start_socket
            self.dragEdge.end_socket = item.socket
            self.dragEdge.start_socket.setConnectedEdge(self.dragEdge)
            self.dragEdge.end_socket.setConnectedEdge(self.dragEdge)
            
            if DEBUG: print('View::edgeDragEnd ~  reassigned start & end sockets to drag edge')
            self.dragEdge.updatePositions()
            return True
        if DEBUG: print('View::edgeDragEnd ~ End dragging edge')
        self.dragEdge.remove()
        self.dragEdge = None
        if DEBUG: print('View::edgeDragEnd ~ about to set socket to previous edge:', self.previousEdge)
        if self.previousEdge is not None:
            self.previousEdge.start_socket.edge = self.previousEdge
        if DEBUG: print('View::edgeDragEnd ~ everything done.')
        return False

    def distanceBetweenClickAndReleaseIsOff(self, event):
        """ measures if we are too far from the last LMB click scene position """
        new_lmb_release_scene_pos = self.mapToScene(event.pos())
        dist_scene = new_lmb_release_scene_pos - self.last_lmb_click_scene_pos
        edge_drag_threshold_sq = EDGE_DRAG_START_THRESHOLD*EDGE_DRAG_START_THRESHOLD
        return (dist_scene.x()*dist_scene.x() + dist_scene.y()*dist_scene.y()) > edge_drag_threshold_sq

    def wheelEvent(self,event):
        zoomOutFactor = 1/self.zoomInFactor

        if event.angleDelta().y() > 0:
            zoomFactor = self.zoomInFactor
            self.zoom += self.zoomStep
        else:
            zoomFactor = zoomOutFactor
            self.zoom -= self.zoomStep

        clamped = False
        if (self.zoom < self.zoomRange[0]):
            self.zoom, clamped = self.zoomRange[0], True
        if (self.zoom > self.zoomRange[1]):
            self.zoom, clamped = self.zoomRange[1], True

        if not clamped or self.zoomClamp is False:
            self.scale(zoomFactor, zoomFactor)

    def create_nodes(self,point):
        self.point = point
        if self.list_flag[0] == 1:
            self.st_init += 1
##            if self.startnode == 1:
##            self.nodename = "Init"
            if self.st_init > 1:
                QMessageBox.about(self, "Init node !", "Only one Init node can be created !")
            else:
                node_st = Start_Node_Init(self.net,self.scene,"Init",inputs=[],outputs=[1])
                node_st.setPos(self.point.x(),self.point.y())
        if self.list_flag[0] == 2:
            self.st_sp += 1
##            self.nodename = "Send_Packet"
            if self.st_sp > 1:
                QMessageBox.about(self, "Send_Packet node !", "Only one Send_Packet node can be created !")
            else:
                node_st = Start_Node_SP(self.net,self.scene,"Send_Packet",inputs=[],outputs=[1])
                node_st.setPos(self.point.x(),self.point.y())
        if self.list_flag[0] == 3:
            self.st_pi += 1
            if self.st_pi > 1:
                QMessageBox.about(self, "Packet_Input node !", "Only one Packet_Input node can be created !")
            else:
                node_st = Start_Node_PI(self.net,self.scene,"Packet_Input",inputs=[],outputs=[1])
                node_st.setPos(self.point.x(),self.point.y())
        if self.list_flag[0] == 4:
            self.st_on += 1
            if self.st_on > 1:
                QMessageBox.about(self, "ON node !", "Only one ON node can be created !")
            else:
                node_st = Start_Node_On(self.net,self.scene,"ON",inputs=[],outputs=[1])
                node_st.setPos(self.point.x(),self.point.y())
        if self.list_flag[0] == 5:
            self.st_off += 1
            if self.st_off > 1:
                QMessageBox.about(self, "OFF node !", "Only one OFF node can be created !")
            else:
                node_st = Start_Node_Off(self.net,self.scene,"OFF",inputs=[],outputs=[1])
                node_st.setPos(self.point.x(),self.point.y())
        if self.list_flag[0] == 6:
            self.st_cci += 1
            if self.st_cci > 1:
                QMessageBox.about(self, "Channel_Check_Interval node !", "Only one channel_check_interval node can be created !")
            else:
                node_st = Start_Node_CCI(self.net,self.scene,"Channel_Check_Interval",inputs=[],outputs=[1])
                node_st.setPos(self.point.x(),self.point.y())
            

        if self.list_flag[0] == 7:
            node_wfp = Waitforpkt_Node(self.net,self.scene,"WaitforPacketNode",inputs=[1],outputs=[1])
            node_wfp.setPos(self.point.x(),self.point.y())

        if self.list_flag[0] == 8:
            node_rb = Randombackoff_Node(self.net,self.scene,"RandomBackoffNode",inputs=[1,2],outputs=[1])
            node_rb.setPos(self.point.x(),self.point.y())

        if self.list_flag[0] == 9:
            node_sp = Sendpacket_Node(self.net,self.scene,"SendPacketNode",inputs=[1,2,3],outputs=[1])
            node_sp.setPos(self.point.x(),self.point.y())


