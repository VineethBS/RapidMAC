
Init Node ----> Wait for Packet Node
Wait for Packet Node ----> Random Backoff Node
Random Backoff Node ----> Send Packet Node

Start_Send_Packet Node ----> Wait for Packet Node
Wait for Packet Node ----> Random Backoff Node
Random Backoff Node ----> Send Packet Node

Start_Packet_Input Node ----> Wait for Packet Node
Wait for Packet Node ----> Random Backoff Node
Random Backoff Node ----> Send Packet Node

Start_ON_Node ----> Wait for Packet Node
Wait for Packet Node ----> Random Backoff Node
Random Backoff Node ----> Send Packet Node

Start_OFF_Node ----> Wait for Packet Node
Wait for Packet Node ----> Random Backoff Node
Random Backoff Node ----> Send Packet Node

Random Backoff Node ----> Send Packet Node
Random Backoff Node ----> Send Packet Node
Random Backoff Node ----> Send Packet Node