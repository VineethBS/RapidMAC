from node_graphics_node import QDMGraphicsNode
from node_content_widget import QDMNodeContentWidget
from node_graphics_scene import QDMGraphicsScene
from node_socket import Socket
from node_socket import *

codefragmenttext = []
nodeslist = []    # list of nodes
p_nodeslist = []  # list of node ids
Attributes = {}
##Edge_attributes = {}

St_node = []
St_Init_node = []
St_SP_node = []
St_PI_node = []
St_On_node = []
St_Off_node = []
St_CCI_node = []
Wp_node = []
Rb_node = []
Sp_node = []
Va_node = []
Fc_node = []
Rv_node = []
Cust_node = []

class Node():
    def __init__(self,scene,title="New Node",inputs=[], outputs=[]):
##        super().__init__(parent)
        self.scene = scene
        self.title = title
        self.nodeinputs = inputs
        self.nodeoutputs = outputs
        self.content = QDMNodeContentWidget()
        self.grNode = QDMGraphicsNode(self)
        self.scene.addNode(self)
        self.scene.grScene.addItem(self.grNode)
        
        self.grScene = QDMGraphicsScene(self.scene)
        self.socket_spacing = 22

        self.inputs = []
        self.outputs = []

##        self.edge_start_node = None
##        self.edge_end_node = None
##        self.index1 = 0
##        self.position1 = 0
##        self.socket_type1 = 0
##        self.index2 = 0
##        self.position2 = 0
##        self.socket_type2 = 0
     
        counter = 0
        for item in self.nodeinputs:
            socket = Socket(node=self, index=counter, position=LEFT_TOP, socket_type=item)  
            counter += 1
            self.inputs.append(socket)

##            print('\nsocket_position_scenePos() : ',socket.scene.grScenePos().x(),socket.scene.grScenePos().y())
            inpos = socket.getSocketPosition()
            print('\nin_getSocketPosition() : ',inpos)
            inpos[0] += socket.node.grNode.pos().x()
            inpos[1] += socket.node.grNode.pos().y()

            print('input socket position: ',(inpos[0],inpos[1]))
##            print('Item At IN:',self.grScene.itemAt(inpos[0],inpos[1]))

        print('self.inputs = ',self.inputs)

        counter = 0
        for item in self.nodeoutputs:
            socket = Socket(node=self, index=counter, position=RIGHT_TOP,socket_type = item)
            counter += 1
            self.outputs.append(socket)

##            outposi = getattr(socket,'nice')
##            print('\nout_socket_position_scenePos() : ',socket.scene.grScenePos().x(),socket.scene.grScenePos().y())
            outpos = socket.getSocketPosition()
            print('\nout_getSocketPosition() : ',outpos)
            outpos[0] += socket.node.grNode.pos().x()
            outpos[1] += socket.node.grNode.pos().y()
            
            print('\noutput socket position: ',(outpos[0],outpos[1]))
##            print('Item At OUT:',self.grScene.itemAt(outpos[0],outpos[1]))

        print('self.outputs = ',self.outputs)

    def __str__(self):
        return "<Node %s..%s>" % (hex(id(self))[2:5], hex(id(self))[-3:])

    @property
    def pos(self):
        return self.grNode.pos()
    def setPos(self, x, y):
        self.grNode.setPos(x, y)

    def getPos(self,x,y):
        self.grNode.getPos(x,y)
        

    def getSocketPosition(self, index, position):
        x = 0 if position in (LEFT_TOP, LEFT_BOTTOM) else self.grNode.width
        if position in (LEFT_BOTTOM, RIGHT_BOTTOM):
            y = self.grNode.height - self.grNode.edge_size - self.grNode._padding - index * self.socket_spacing
        else:
            y = self.grNode.title_height + self.grNode._padding + self.grNode.edge_size + index * self.socket_spacing

        return [x, y]

    def updateConnectedEdges(self):
        
        for socket in self.inputs + self.outputs:
            if socket.hasEdge():
                socket.edge.updatePositions()

                if socket in self.inputs:
                    self.edge_start_node = hex(id(socket.node.grNode))
                    self.index1 = socket.index
                    self.position1 = socket.position
                    self.socket_type1 = socket.socket_type
                if socket in self.outputs:
                    self.edge_end_node = hex(id(socket.node.grNode))
                    self.index2 = socket.index
                    self.position2 = socket.position
                    self.socket_type2 = socket.socket_type
##                Edge_attributes[(self.edge_start_node,self.edge_end_node)] = {'index1':self.index1,'position1':self.position1,'socket_type1':self.socket_type1,'index2':self.index2,'position2':self.position2,'socket_type2':self.socket_type2}
##                print('\n Edge Attributes = ',Edge_attributes)
            

class Start_Node_Init(Node):
    def __init__(self,node_content,position,scene,title="Init",inputs=[],outputs=[]):
        
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Init",inputs=[], outputs=[])
        St_Init_node.append(hex(id(self.grNode)))
##        self.net.add_node(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}
##        codefragmenttext.append("StartNode_Init")
##        print(self.node_content)
##        print('________________________________________________________________________________________')
##        self.net.add_node(hex(id(self.grNode)),Attributes[hex(id(self.grNode))])
##        return self.net
##        print('Attributes = ',Attributes)

class Start_Node_SP(Node):
    def __init__(self,node_content,position,scene,title="Send_Packet",inputs=[],outputs=[]):
        
        self.node_content = node_content
        self.position = position
        
        Node.__init__(self,scene,title="Send_Packet",inputs=[], outputs=[1])
        St_SP_node.append(hex(id(self.grNode)))
##        self.net.add_node(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}
##        codefragmenttext.append("StartNode_send_packet")
##        print(self.node_content)
##        print('________________________________________________________________________________________')
##        print('Attributes = ',Attributes)
##        return self.node_content
##        self.net.add_node(hex(id(self.grNode)),Attributes[hex(id(self.grNode))])
##        return self.net

class Start_Node_PI(Node):
    def __init__(self,node_content,position,scene,title="Packet_Input",inputs=[],outputs=[]):
        
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Packet_Input",inputs=[], outputs=[1])
        St_PI_node.append(hex(id(self.grNode)))
##        self.net.add_node(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}
##        codefragmenttext.append("StartNode_Packet_Input")
##        print(self.node_content)
##        print('________________________________________________________________________________________')
##        print('Attributes = ',Attributes)
##        return self.node_content
##        self.net.add_node(hex(id(self.grNode)),Attributes[hex(id(self.grNode))])
##        return self.net

class Start_Node_On(Node):
    def __init__(self,node_content,position,scene,title="On",inputs=[],outputs=[]):
        
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="On",inputs=[], outputs=[1])
        St_On_node.append(hex(id(self.grNode)))
##        self.net.add_node(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}
##        codefragmenttext.append("StartNode_On")
##        print(self.node_content)
##        print('________________________________________________________________________________________')
##        print('Attributes = ',Attributes)
##        return self.node_content
##        self.net.add_node(hex(id(self.grNode)),Attributes[hex(id(self.grNode))])
##        return self.net

class Start_Node_Off(Node):
    def __init__(self,node_content,position,scene,title="Off",inputs=[],outputs=[]):
        
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Off",inputs=[], outputs=[1])
        St_Off_node.append(hex(id(self.grNode)))
##        self.net.add_node(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}
##        codefragmenttext.append("StartNode_Off")
##        print(self.node_content)
##        print('________________________________________________________________________________________')
##        return self.node_content
##        print('Attributes = ',Attributes)
##        self.net.add_node(hex(id(self.grNode)),Attributes[hex(id(self.grNode))])
##        return self.net
        
class Start_Node_CCI(Node):
    def __init__(self,node_content,position,scene,title="Channel_check_Interval",inputs=[],outputs=[]):
        
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Channel_check_Interval",inputs=[], outputs=[1])
        St_CCI_node.append(hex(id(self.grNode)))
##        self.net.add_node(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}
##        codefragmenttext.append("StartNode_Channel_check_Interval")
##        print(self.node_content)
##        print('________________________________________________________________________________________')
##        print('Attributes = ',Attributes)
##        return self.node_content
##        self.net.add_node(hex(id(self.grNode)),Attributes[hex(id(self.grNode))])
##        return self.net
        
class Waitforpkt_Node(Node):
    def __init__(self,node_content,position,scene,title="Wait for packet Node",inputs=[],outputs=[]):
        
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Wait for packet Node",inputs=[1], outputs=[1])
        Wp_node.append(hex(id(self.grNode)))
##        self.net.add_node(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}
##        codefragmenttext.append("Wait for packet Node")
##        print(self.node_content)
##        print('________________________________________________________________________________________')
##        print('Attributes = ',Attributes)
##        self.net.add_node(hex(id(self.grNode)),Attributes[hex(id(self.grNode))])
##        return self.net
        

class Randombackoff_Node(Node):
    def __init__(self,node_content,position,scene,title="Randombackoff Node",inputs=[],outputs=[]):
##        self.net = net
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Random backoff Node",inputs=[1,2], outputs=[1])
        Rb_node.append(hex(id(self.grNode)))
##        self.net.add_node(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}
##        codefragmenttext.append("Random Backoff Node")
##        print(self.node_content)
##        print('________________________________________________________________________________________')
##        print('Attributes = ',Attributes)
##        self.net.add_node(hex(id(self.grNode)),Attributes[hex(id(self.grNode))])
##        return self.net

class Sendpacket_Node(Node):
    def __init__(self,node_content,position,scene,title="Sendpacket Node",inputs=[],outputs=[]):
        
        self.node_content = node_content
        self.position = position
        print('\nNodeposition:',self.position)
        Node.__init__(self,scene,title="Send packet Node",inputs=[1,2,3], outputs=[1])
        Sp_node.append(hex(id(self.grNode)))
##        self.net.add_node(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}
##        codefragmenttext.append("Sendpacket Node")
##        print(self.node_content)
##        print('________________________________________________________________________________________')
##        print('Attributes = ',Attributes)
##        self.net.add_node(hex(id(self.grNode)),Attributes[hex(id(self.grNode))])
##        return self.net

class ReturnValue_Node(Node):
    def __init__(self,node_content,position,scene,title="Return Value Node",inputs=[],outputs=[]):
        
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Return Value Node",inputs=[1], outputs=[])
        Rv_node.append(hex(id(self.grNode)))
##        self.net.add_node(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)        
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}
##        codefragmenttext.append("Return Value Node")
##        print(self.node_content)
##        print(self.ret_node_content)
##        print('________________________________________________________________________________________')
##        print('Attributes = ',Attributes)
##        self.net.add_node(hex(id(self.grNode)),Attributes[hex(id(self.grNode))])
##        return self.net


class FunctionCall_Node(Node):
    def __init__(self,node_content,position,scene,title="Function Call Node",inputs=[],outputs=[]):
    
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Function Call Node",inputs=[1], outputs=[1])
        Fc_node.append(hex(id(self.grNode)))
##        self.net.add_node(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}
##        codefragmenttext.append("Function Call Node")
##        print(self.node_content)
##        print('________________________________________________________________________________________')
##        print('Attributes = ',Attributes)
##        self.net.add_node(hex(id(self.grNode)),Attributes[hex(id(self.grNode))])
##        return self.net


class VariableAssign_Node(Node):
    def __init__(self,node_content,position,scene,title="Variable Assignment Node",inputs=[],outputs=[]):
        
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Variable Assignment Node",inputs=[1], outputs=[1])
        Va_node.append(hex(id(self.grNode)))
##        self.net.add_node(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}
##        codefragmenttext.append("Variable Assignment Node")
##        print(self.node_content)
##        print('________________________________________________________________________________________')
##        print('Attributes = ',Attributes)
##        self.net.add_node(hex(id(self.grNode)),Attributes[hex(id(self.grNode))])
##        return self.net

class CustomCode_Node(Node):
    def __init__(self,node_content,position,scene,title="Custom Code Node",inputs=[],outputs=[]):
        
        self.node_content = node_content
        self.position = position
        Node.__init__(self,scene,title="Custom Code Node",inputs=[1], outputs=[1])
        Cust_node.append(hex(id(self.grNode)))
##        self.net.add_node(hex(id(self.grNode)))
        p_nodeslist.append(hex(id(self.grNode)))
        nodeslist.append(self.grNode)
        Attributes[hex(id(self.grNode))] = {'pos':self.position,'name':self.title,'contents':self.node_content}
##        codefragmenttext.append("Custom Code Node")
##        print(self.node_content)
##        print('________________________________________________________________________________________')
##        print('Attributes = ',Attributes)
##        self.net.add_node(hex(id(self.grNode)),Attributes[hex(id(self.grNode))])
##        return self.net



         
