from node_graphics_edge import *
from node_node import Attributes
from node_socket import Socket
from node_graphics_socket import QDMGraphicsSocket
##from node_graphics_view import flag

EDGE_TYPE_DIRECT = 1
EDGE_TYPE_BEZIER = 2

DEBUG = False

codefragment = []
edge_startnode = []
edge_endnode = []

NODE_1 = 0

Edge_attributes = {}
New_socket_attr = []
New_end_socket_attr = []


class Edge:
    def __init__(self,scene,start_socket,end_socket, edge_type=EDGE_TYPE_BEZIER):
        print('\n ............. Entering node_edge ..............\n')
        self.scene = scene
        self.start_socket = start_socket
        self.end_socket = end_socket
        self.Attributes = Attributes
        self.Edge_attributes = Edge_attributes
##        print('start socket:',self.start_socket)
        self.start_socket.edge = self
        if self.end_socket is not None:
            self.end_socket.edge = self
            
        self.grEdge = QDMGraphicsEdgeDirect(self) if edge_type==EDGE_TYPE_DIRECT else QDMGraphicsEdgeBezier(self)

        if self.start_socket is QDMGraphicsSocket and self.end_socket is QDMGraphicsSocket:
            print('------graphics socket------')
            pass
        else:
            self.updatePositions()
        
##        print('Attributes : ',self.Attributes)
        
        self.scene.grScene.addItem(self.grEdge)
        self.scene.addEdge(self)

            
        print('\n ............. Leaving node_edge ..............\n')

    def __str__(self):
        return "<Edge %s..%s>" % (hex(id(self))[2:5], hex(id(self))[-3:])

    def updatePositions(self):
        print('\n ............. In node_edge : updatePositions..............\n')
        if self.start_socket is not None:
            source_pos = self.start_socket.getSocketPosition()
            source_pos[0] += self.start_socket.node.grNode.pos().x()
            source_pos[1] += self.start_socket.node.grNode.pos().y()

            print('\n(source_pos[0],source_pos[1])=',source_pos[0],source_pos[1])

##        New_end_socket_attr.append((self.start_socket,(source_pos[0],source_pos[1])))
        
        print('\n\n *source_pos = ',*source_pos)
        self.grEdge.setSource(*source_pos)
####        if flag == 1:
####            self.grEdge.setSource(*source_pos)
        if self.end_socket is not None:
            end_pos = self.end_socket.getSocketPosition()
            end_pos[0] += self.end_socket.node.grNode.pos().x()
            end_pos[1] += self.end_socket.node.grNode.pos().y()

            New_socket_attr.append((self.start_socket,(source_pos[0],source_pos[1]),
                                    self.end_socket,(end_pos[0],end_pos[1])))

            print('\n\nSocket attributes: \n',New_socket_attr)

            self.edge_startnode = hex(id(self.start_socket.node.grNode)) 
            self.edge_endnode = hex(id(self.end_socket.node.grNode))  

            codefragment.append((self.edge_startnode,self.edge_endnode))
            
            L = len(codefragment)
            if L > 1:
                for a in range (0,L-1):
                    if ((codefragment[a][0] == self.edge_startnode) and (codefragment[a][1] == self.edge_endnode)):
                        del codefragment[-1]
            print('\n\n *end_pos = ',*end_pos)
            self.grEdge.setDestination(*end_pos)

            source_position = (source_pos[0],source_pos[1])
            end_position = (end_pos[0],end_pos[1])

            for key,val in self.Attributes.items():
                for attr,values in val.items():
                    self.Attributes[self.edge_startnode]['pos'] = self.start_socket.node.grNode.pos()
                    self.Attributes[self.edge_endnode]['pos'] = self.end_socket.node.grNode.pos()

            Edge_attributes[(self.edge_startnode,self.edge_endnode)] = {'source_pos':source_position,'end_pos':end_position}
            print('\n Edge Attributes = ',Edge_attributes)
        else:
            self.grEdge.setDestination(*source_pos)
        self.grEdge.update()        

    def remove_from_sockets(self):
        print('***** remove_from_sockets... ******')
        if self.start_socket is not None:
            self.start_socket.edge = None
        if self.end_socket is not None:
            self.end_socket.edge = None

        self.end_socket = None
        self.start_socket = None
        codefragment.remove((self.edge_startnode,self.edge_endnode))
        del self.Edge_attributes[(self.edge_startnode,self.edge_endnode)]

    def remove(self):
        print('**** remove ****')
        self.remove_from_sockets()
        self.scene.grScene.removeItem(self.grEdge)
        self.grEdge = None
        self.scene.removeEdge(self)


