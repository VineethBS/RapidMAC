Start Node ----> Wait for Packet Node
