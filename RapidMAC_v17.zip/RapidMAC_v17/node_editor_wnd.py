import networkx as nx
import matplotlib.pyplot as plt

from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *

from node_scene import Scene
from node_graphics_view import QDMGraphicsView
from node_edge import Edge, EDGE_TYPE_BEZIER

##nodeid = []

class NodeEditorWnd(QWidget):
    def __init__(self,parent,list_flag,net):
##        print('*----node_editor_wnd----*')
        super().__init__(parent)
        self.list_flag = list_flag
        self.net = net
##        G = nx.Graph()
        self.initUI()

    def initUI(self):
        self.setGeometry(200, 200, 800, 600)
        self.layout = QVBoxLayout()
        self.layout.setContentsMargins(0, 0, 0, 0)

        self.setLayout(self.layout)

        self.scene = Scene()

#        self.addNodes()
#        self.create_nodes()  
        
        self.view =  QDMGraphicsView(self.scene.grScene,self.scene,self.net,self.list_flag,self)

        self.layout.addWidget(self.view)
        self.setWindowTitle("Node Editor")
        self.show()
##
##    def loadStylesheet(self, filename):
##        print('STYLE loading:', filename)
##        file = QFile(filename)
##        file.open(QFile.ReadOnly | QFile.Text)
##        stylesheet = file.readAll()
##        QApplication.instance().setStyleSheet(str(stylesheet, encoding='utf-8'))
##


