Start Node ----> Wait for Packet Node
Wait for Packet Node ----> Send Packet Node
Random Backoff Node ----> Send Packet Node
