
static void
init(void)
{
}
/*---------------------------------------------------------------------------------*/

static void 
send_packet(mac_callback_t sent, void *ptr)
{
	p.sent = sent;                
	p.ptr = ptr;
	clock_time_t delay = random_rand() % CLOCK_SECOND;                
	PRINTF('Simple-ALOHA : at %u scheduling transmission in %u ticks\n', (unsigned) clock_time(),(unsigned) delay);                
	ctimer_set(&transmit_timer, delay, _send_packet, &p);
	sent(ptr, MAC_TX_DEFERRED, 1);
}
/*---------------------------------------------------------------------------------*/

static void 
packet_input(void)
{
	NETSTACK_LLSEC.input();
}
/*---------------------------------------------------------------------------------*/

static int
on(void)
{
	return NETSTACK_RDC.on();
}
/*---------------------------------------------------------------------------------*/

static int
off(int keep_radio_on)
{
	return NETSTACK_RDC.off(keep_radio_on);
}
/*---------------------------------------------------------------------------------*/

static unsigned short
channel_check_interval(void)
{
	return 0;
}
/*---------------------------------------------------------------------------------*/


Start_Send_Packet Node -----> Wait for Packet Node
Wait for Packet Node -----> Random Backoff Node
Random Backoff Node -----> Send Packet Node

Start_Packet_Input Node -----> Wait for Packet Node
Wait for Packet Node -----> Random Backoff Node
Random Backoff Node -----> Send Packet Node

Start_ON_Node -----> Wait for Packet Node
Wait for Packet Node -----> Random Backoff Node
Random Backoff Node -----> Send Packet Node

Start_OFF_Node -----> Wait for Packet Node
Wait for Packet Node -----> Random Backoff Node
Random Backoff Node -----> Send Packet Node

Start_Channel_Check_Interval Node -----> Wait for Packet Node
Wait for Packet Node -----> Random Backoff Node
Random Backoff Node -----> Send Packet Node